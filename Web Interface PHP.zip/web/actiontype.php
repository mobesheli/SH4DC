<?php

session_start();
if (isset($_POST['actiontype']))
{
	$_SESSION['actiontype']=$_POST['actiontype'];
}
	$submitted_action=$_SESSION['actiontype'];

if (isset($_GET['action_id']))
{
	$_SESSION['action_id']=$_GET['action_id'];
}
$submitted_ID=$_SESSION['action_id'];
//echo $submitted_ID;
if (isset($_GET['action_type']))
{
	$_SESSION['action_type']=$_GET['action_type'];
}
$submitted_type=$_SESSION['action_type'];
if (isset($_POST['ent_command_submit']))
{
	$_SESSION['ent_command_submit']=$_POST['ent_command_submit'];
}
$submitted_ent_command=$_SESSION['ent_command_submit'];
//
if (isset($_POST['dateex']))
{
	$_SESSION['dateex']=$_POST['dateex'];
}
$submitted_dateex=$_SESSION['dateex'];
//
if (isset($_POST['interfaceselect']) )
{
	$_SESSION['interfaceselect']=$_POST['interfaceselect'];
}
$submitted_interfaceselect=$_SESSION['interfaceselect'];
if (isset($_POST['actselect']) )
{
	$_SESSION['actselect']=$_POST['actselect'];
}
$submitted_actselect=$_SESSION['actselect'];

if (isset($_POST['ent_command']))
{
	$_SESSION['ent_command']=$_POST['ent_command'];
}
$submitted_message=$_SESSION['ent_command'];

if (isset($_POST['ent_command_act']))
{
	$_SESSION['ent_command_act']=$_POST['ent_command_act'];
}
$submitted_message_act=$_SESSION['ent_command_act'];

$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con);
//print_r($_SESSION);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>The Action Type</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="js/jquery-ui/jquery-ui.css" />
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery-ui/jquery-ui.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<script>
		$( document ).ready(function() {
      $('#help_button').click(function(event){
        event.preventDefault();
				$( "#help" ).dialog({
					modal: true,
					buttons: {
						Ok: function() {
							$( this ).dialog( "close" );
						}
					},
					width: 'auto'
				});
      });
    });

	</script>
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
        <nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Configurations</a></li>
						<li><a href="Details.html">About</a></li>
					</ul>
				</nav>
				</nav>
			</header>

		<!-- Main -->

<section id="main" class="wrapper">
	<div class="container">
		<header class="major">
			<h2>The Action Type</h2>
			<p>This is the action type for the alert <?php echo $submitted_ID; ?>.</p>
		</header>


	<div class="row 100%">
		<section class="12u 12u$(small)">
			<p>In this page, you can change the system action type of the detected situation. Currently, you are changing the action type for alert <?php echo $submitted_ID; ?>, which is <?php echo $submitted_type;?>. </br>
		The system is capable of reacting in one of the following types (for more information, please hover on them or <a id="help_button" href=""> click here</a>):</br>
			<div id="help" style="display: none">
					Inviting Awareness: In this level, the system does not intervene in PwD’s life. It merely monitors a  predefined activity and records it in a log database.  Later, the log data could be adapted to produce reports for stakeholders (e.g., PwD, caregivers). The reports will be used to invite awareness about the situation.<br/>
					Suggesting: In this level, the system employs its interfaces to suggest an action in regards to a specific situation. The PwD is free to act on suggestions or take an alternative decision. For instance, the system suggests a particular dress considering the outside temperature and dress availability. The system does not need to monitor PwD's reactions to the suggestion.<br/>
					Prompting: In this level, the system reminds a PwD to perform a predefined activity. In contrary to the suggestion, the PwD should not ignore the prompts; if the PDW does not consider the prompts the system will act and intervene. For instance, the system reminds the PwD to take his medicines. However, if the PwD does not react the system needs to intervene (i.e., by informing the caregivers). <br/>
					Urging:In this level, the system prompts the PwD to perform an action and it intervenes at the same time. The level is important for tasks that involve both the PwD and the system actions. For instance, if the PwD forgets to turn the oven off, the system should turn the oven off and remind a stakeholder. <br/>
					Performing: In this level, the system intervenes without any preconditions. It works regardless of the stakeholder actions. The intervention happens as a quick Journey Ahead reaction to a risky situation. For instance, when the PwD falls and does not move, the system calls the caregiver.<br/>
			</div>
			</p>
		 <p><a href='ac-formal.php'> Back to monitoring</a></p>




		</section>
    <form action="#" method="post">
    <section  class="12u 12u$(small)">
      <strong><p>Please select your action:</br></p></strong>
      <select name="actiontype">
        <option value=""> <?php echo $submitted_type; ?> </option>
        <option value="Inviting Awareness"> Inviting Awareness </option>
        <option value="Suggesting"> Suggesting </option>
        <option value="Prompting"> Prompting </option>
        <option value="Urging"> Urging </option>
        <option value="Performing"> Performing </option>
      </select>
    </br>
      <input name="action_submit" type="submit" value="Change">
    </form>
    </section>

<!-- THIS IS A TEST ENVIRONMENT, ENTER WITH CAUTION-->

 <?php
  echo $submitted_action;
  echo "</br>";
  switch ($submitted_action) {
    case 'Inviting Awareness':
      echo "<div class=\"12u 12u$(small)\">";
      $ent_uptdate=mysql_query("UPDATE `Alertcenter`.`Messages` SET  `actiontype`='Inviting Awareness' WHERE `msg_id`='$submitted_ID'");
			echo "<p> You have successfully modified the action type for this event to inviting awareness. This message will be presented to different users through their monitoring applications. </p>";
			break;


    case 'Suggesting':

		echo "<div class=\"row uniform 50%\">";
		echo "<form action='actiontype.php' method='POST'>";
			echo "<div class=\"6u 12u$(small)\">";
			echo "<p>Please select the interface for suggesting</p>";
			echo "<select name='interfaceselect'>";
    	echo "<p> The suggesting allows you to send messages to the residents using a predefined system interface. </p>";
			$ent_uptdate=mysql_query("UPDATE `Alertcenter`.`Messages` SET  `actiontype`='Suggesting' WHERE `msg_id`='$submitted_ID'");
			$ent_action=mysql_query("SELECT DISTINCT `ent_name` FROM `systementity` WHERE `ent_type` = 'interface' ");
			while($r = mysql_fetch_assoc($ent_action))
					{
					echo "<option value=";
					echo $r['ent_name'];
					echo '>';
					echo $r['ent_name'];
					echo "</option>";
					}
			echo "</select>";
				echo "</div>";
				echo "<div  class=\"6u$ 12u$(xsmall)\">";
				echo "Running time schedule: ";
				echo "<input type='text' name='dateex' id='dateex'>";
				echo "</div>";
				echo "</br>";


			echo "<p> Message: </p>";
      echo "<section class=\"12u 12u$(xsmall)\">";
			echo "<textarea name='ent_command' id='ent_command' rows='15' cols='100'></textarea>";
			echo "</br>";
			echo  "<input name='ent_command_submit' id='ent_command_submit' type='submit' value='Send'> ";

			echo "</form>";
			echo "</section>";

			echo "</br>";

			if (isset($submitted_ent_command)) {
				$ent_command_sql=mysql_query ("INSERT INTO `testsensors`.`systementity` (`ent_type`, `Ex_date`, `ent_command`, `ent_name`) VALUES ( 'interface', '$submitted_dateex', '$submitted_message', '$submitted_interfaceselect')");
				//echo $submitted_message;
				session_destroy();
			}
			echo "</div>";
      break;
    case 'Prompting':
		echo "<div class=\"12u 12u$(small)\">";
		echo "<form action='actiontype.php' method='POST'>";
		echo "<select name='actselect' width=\"300\" style=\"width: 300px\">";
		echo "<p> The suggesting allows you to send messages to the residents using a predefined system interface. </p>";
			$ent_uptdate=mysql_query("UPDATE `Alertcenter`.`Messages` SET  `actiontype`='Prompting' WHERE `msg_id`='$submitted_ID'");
		$ent_action=mysql_query("SELECT DISTINCT `ent_name` FROM `systementity` WHERE `ent_type` = 'interface' ");
			while($r = mysql_fetch_assoc($ent_action))
					{
					echo "<option value=";
					echo $r['ent_name'];
					echo '>';
					echo $r['ent_name'];
					echo "</option>";
					}
			echo "</select>";
				echo "</br>";
				echo "Running time schedule: ";
				echo "<input type='date' name='dateex' id='dateex'>";
				echo "</br>";
			echo "<p> Message: </p>";
   		echo "<textarea name='ent_command' id='ent_command' rows='20' cols='40'></textarea>";
			echo "</br>";
			echo "</br>";
			echo "</br>";

			echo "</br>";
			echo "If the the condition stated the same until the following time";
			echo "<input type='date' name='dateex' id='dateex'>";
			echo "</br>";
      echo "</br>";
			echo "<p> The following actuator should run this command";

			echo "<select name='actuatorselect'width=\"300\" style=\"width: 300px\"></p>";

			$ent_action_act=mysql_query("SELECT DISTINCT `ent_name` FROM `systementity` WHERE `ent_type` = 'act' ");
				while($act = mysql_fetch_assoc($ent_action_act))
						{
						echo "<option value=";
						echo $act['ent_name'];
						echo '>';
						echo $act['ent_name'];
						echo "</option>";
						}
				echo "</select>";
					echo "</br>";

				echo "<p> Commands: </p>";
				echo "<textarea name='ent_command_act' id='ent_command_act' rows='20' cols='40'></textarea>";
				echo "</br>";
				echo  "<input name='ent_command_submit' id='ent_command_submit' type='submit' value='Send'> ";
				echo "</form>";


			if (isset($submitted_ent_command)) {
			$ent_command_sql=mysql_query ("INSERT INTO `testsensors`.`systementity` (`ent_type`, `Ex_date`, `ent_command`, `ent_name`) VALUES ( 'interface', '$submitted_dateex', '$submitted_message', '$submitted_interfaceselect')");
			$ent_command_sql_act=mysql_query ("INSERT INTO `testsensors`.`systementity` (`ent_type`, `Ex_date`, `ent_command`, `ent_name`) VALUES ( 'act', '$submitted_dateex', '$submitted_message_act', '$submitted_actselect')");

								//echo $submitted_message;
								session_destroy();
							}
      break;





		case 'Urging':

			echo "<div class=\"12u 12u$(small)\">";
			echo "<form action='actiontype.php' method='POST'>";
			echo "<select name='actselect' width=\"300\" style=\"width: 300px\">";
			echo "<p> The suggesting allows you to send messages to the residents using a predefined system interface. </p>";
				$ent_uptdate=mysql_query("UPDATE `Alertcenter`.`Messages` SET  `actiontype`='Urging' WHERE `msg_id`='$submitted_ID'");
			$ent_action=mysql_query("SELECT DISTINCT `ent_name` FROM `systementity` WHERE `ent_type` = 'interface' ");
				while($r = mysql_fetch_assoc($ent_action))
						{
						echo "<option value=";
						echo $r['ent_name'];
						echo '>';
						echo $r['ent_name'];
						echo "</option>";
						}
				echo "</select>";
					echo "</br>";
					echo "Running time schedule: ";
					echo "<input type='date' name='dateex' id='dateex'>";
					echo "</br>";
				echo "<p> Message: </p>";
				echo "<textarea name='ent_command' id='ent_command' rows='20' cols='40'></textarea>";
				echo "</br>";
				echo "</br>";
				echo "</br>";
				echo "<p> The following actuator should run this command";
				echo "<select name='actuatorselect'width=\"300\" style=\"width: 300px\"></p>";
				$ent_action_act=mysql_query("SELECT DISTINCT `ent_name` FROM `systementity` WHERE `ent_type` = 'act' ");
					while($act = mysql_fetch_assoc($ent_action_act))
							{
							echo "<option value=";
							echo $act['ent_name'];
							echo '>';
							echo $act['ent_name'];
							echo "</option>";
							}
					echo "</select>";
						echo "</br>";
					echo "<p> Commands: </p>";
					echo "<textarea name='ent_command_act' id='ent_command_act' rows='20' cols='40'></textarea>";
					echo "</br>";
					echo  "<input name='ent_command_submit' id='ent_command_submit' type='submit' value='Send'> ";
					echo "</form>";


				if (isset($submitted_ent_command)) {
				$ent_command_sql=mysql_query ("INSERT INTO `testsensors`.`systementity` (`ent_type`, `Ex_date`, `ent_command`, `ent_name`) VALUES ( 'interface', '$submitted_dateex', '$submitted_message', '$submitted_interfaceselect')");
				$ent_command_sql_act=mysql_query ("INSERT INTO `testsensors`.`systementity` (`ent_type`, `Ex_date`, `ent_command`, `ent_name`) VALUES ( 'act', '$submitted_dateex', '$submitted_message_act', '$submitted_actselect')");

									//echo $submitted_message;
									session_destroy();
								}
      break;
    case 'Performing':

			echo "<div class=\"4u 12u$(small)\">";
			echo "<form action='actiontype.php' method='POST'>";
			echo "<select name='interfaceselect'>";
			echo "<p> action that should be performed. </p>";
			$ent_uptdate=mysql_query("UPDATE `Alertcenter`.`Messages` SET  `actiontype`='Performing' WHERE `msg_id`='$submitted_ID'");
			$ent_action_act=mysql_query("SELECT DISTINCT `ent_name` FROM `systementity` WHERE `ent_type` = 'act' ");
				while($act = mysql_fetch_assoc($ent_action_act))
						{
						echo "<option value=";
						echo $act['ent_name'];
						echo '>';
						echo $act['ent_name'];
						echo "</option>";
						}
				echo "</select>";
					echo "</br>";
					echo "Running time schedule: ";
					echo "<input type='text' name='dateex' id='dateex'>";
					echo "</br>";

				echo "</div>";
				echo "<p> Command: </p>";
				echo "<section class=\"12u 12u$(small)\">";
				echo "<textarea name='ent_command' id='ent_command' rows='20' cols='50'></textarea>";
				echo "</br>";
				echo  "<input name='ent_command_submit' id='ent_command_submit' type='submit' value='Send'> ";

				echo "</form>";
				echo "</section>";

				echo "</br>";
      break;

  }
//



   ?>






	</div>

		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>
