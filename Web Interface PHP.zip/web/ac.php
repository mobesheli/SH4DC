<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("Alertcenter", $con);
// critical system messages.
$csm = mysql_query("SELECT `date2`,`mes` FROM `Messages` WHERE `sender` LIKE 'system' AND `flag` = 0 AND `pr` = 0");
// non-critical system messages.
$nsm = mysql_query("SELECT `date2`,`mes` FROM `Messages` WHERE `sender` LIKE 'system' AND `flag` = 1 AND `pr` = 0");
// critical caregiver messages.
$ccm = mysql_query("SELECT `date2`,`mes` FROM `Messages` WHERE `sender` LIKE 'caregiver' AND `flag` = 0 AND `pr` = 0");
// non-critical caregiver messages.
$ncm = mysql_query("SELECT `date2`,`mes` FROM `Messages` WHERE `sender` LIKE 'caregiver' AND `flag` = 1 AND `pr` = 0");
// general messages.
$gm = mysql_query("SELECT `date2`,`mes` FROM `Messages` WHERE `flag` = 2");
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Alert Center</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Management</a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
        
<section id="main" class="wrapper">
	<div class="container">
		<header class="major">
			<h2>The Alert Center</h2>
			<p>General health updates.</p>
		</header>
					
	<div class="row 100%">
	<section class="12u 12u$(small)">
			<p>The PwD's Overall Situation is:</p>
	</section>
<?php 
//This is the overalll alert:
$num_csm = mysql_num_rows($csm);
$num_nsm = mysql_num_rows($nsm);
$num_ccm = mysql_num_rows($ccm);
$num_ncm = mysql_num_rows($ncm);
$overall= ($num_csm + $num_ccm) * 10 + ($num_nsm + $num_ncm);
	if ($overall >= 10) 
	{
		echo '<section class="12u 12u$(small)">
						<i class="icon big rounded fa-exclamation "></i>
						<h2>Risky</h2>
						<p> The number of alerts are more than average.</p>
				</section>';
	}
	else if ($overall < 10 && $overall > 0 ) 
	{
		echo '<section class="12u 12u$(small)">
						<i class="icon big rounded fa-check"></i>
						<h2>No immediate risks</h2>
						<p> There are some alerts but not critical ones.</p>
				</section>';
	}
	else 
	{
		echo '<section class="12u 12u$(small)">
						<i class="icon big rounded fa-check-circle-o"></i>
						<h2>No risks</h2>
						<p> There are no alerts in the system.</p>
				</section>';
	}
?>
		<section class="12u 12u$(small)">
			<p>Please consider the following health reports.</p>
		</section>
		<!-- critical system messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #C00">critically risky</span> situations detected by the system. </p>
		</div>
		<div>
		<table>
		<td width="41%" class="table-wrapper">Date</td>
    	<td width="59%" class="table-wrapper">Message</td>
		<?php
		
		
              while ($row = mysql_fetch_array($csm)) {
                   $time = strtotime($row[0]);
				   $myFormatForView = date("m/d/y g:i A", $time);
				   echo "<tr>";
				   echo "<td>".$myFormatForView."</td>";
                   echo "<td>".$row[1]."</td>";
                   echo "</tr>";
               }

		?> 
		</table>	
		</div>
		</section>
					
		<!-- non-critical system messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #CF0">non-critical</span> situation detected by the system. </p>
		</div>
		<div>
		<table>
		<td width="41%" class="table-wrapper">Date</td>
    	<td width="59%" class="table-wrapper">Message</td>
		<?php
		
		
              while ($row = mysql_fetch_array($nsm)) {
                   $time = strtotime($row[0]);
				   $myFormatForView = date("m/d/y g:i A", $time);
				   echo "<tr>";
				   echo "<td>".$myFormatForView."</td>";
                   echo "<td>".$row[1]."</td>";
                   echo "</tr>";
               }

		?> 
		</table>	
		</div>
		</section>
		
		<!-- critical caregiver messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #C00">critically risky</span> situation detected by the caregivers. </p>
		</div>
		<div>
		<table>
		<td width="41%" class="table-wrapper">Date</td>
    	<td width="59%" class="table-wrapper">Message</td>
		<?php
		
		
              while ($row = mysql_fetch_array($ccm)) {
                   $time = strtotime($row[0]);
				   $myFormatForView = date("m/d/y g:i A", $time);
				   echo "<tr>";
				   echo "<td>".$myFormatForView."</td>";
                   echo "<td>".$row[1]."</td>";
                   echo "</tr>";
               }

		?> 
		</table>	
		</div>
		</section>								
                    
	</div>
		
		<!-- non-critical caregiver messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #CF0">non-critical</span> situations detected by the caregiver. </p>
		</div>
		<div>
		<table>
		<td width="41%" class="table-wrapper">Date</td>
    	<td width="59%" class="table-wrapper">Message</td>
		<?php
		
		
              while ($row = mysql_fetch_array($ncm)) {
                   $time = strtotime($row[0]);
				   $myFormatForView = date("m/d/y g:i A", $time);
				   echo "<tr>";
				   echo "<td>".$myFormatForView."</td>";
                   echo "<td>".$row[1]."</td>";
                   echo "</tr>";
               }

		?> 
		</table>	
		</div>
		</section>	
		
		<!-- General messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #0F0">General</span> situations. </p>
		</div>
		<div>
		<table>
		<td class="table-wrapper">Date</td>
    	<td class="table-wrapper">Message</td>
		<?php
		
		
              while ($row = mysql_fetch_array($gm)) {
                   $time = strtotime($row[0]);
				   $myFormatForView = date("m/d/y g:i A", $time);
				   echo "<tr>";
				   echo "<td>".$myFormatForView."</td>";
                   echo "<td>".$row[1]."</td>";
                   echo "</tr>";
               }

		?> 
		</table>	
		</div>
		</section>	
		
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>