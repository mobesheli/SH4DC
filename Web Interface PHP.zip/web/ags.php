<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Automatic Guide playing System</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Configurations</a></li>
						<li><a href="Details.html">About</a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
        
<section id="main" class="wrapper">
	<div class="container">
		<header class="major">
			<h2>Automatic Guide playing System</h2>
			<p>This system is designed to enable playing a customised message (interactive guide) for any newly added device to the home perimeter each time the PwD start interacting with them. .</p>
		</header>

						
	<div class="row 100%">
		<section class="6u 12u$(small)">
			<form action="#" method="POST">
			<p> Select the device that using it by the PwD needs the guides:
			<select id="device" name="selected_device">
			  <option value="">--select--</option>
			  <option value="Sony_TV">The TV in the living room</option>
			  <option value="Microwave">The Microwave</option>
			  <option value="SMS">Sending an SMS</option>
			</select>
			</p>
			
			
		</section>
		
		<section class="6u 12u$(small)">
		<p> Plese select the media file that should be played.
 		 <input type="file" name="guide" accept="media_type">
  			
		</p>
		</section method="POST">
		
		<section class="6u 12u$(small)">
			<p> Select the interface:
			<select id="int" name="selected_int">
			  <option value="">--select--</option>
			  <option value="H_Speakers">Hall Speakers</option>
			  <option value="K_Speakers">Kitchen Speakers</option>
			  <option value="TV">The TV</option>
			  <option value="Radio">The Radio</option>
			</select>
			</p>
			
			
		</section>
		
		<section class="12u 12u$(small)">
		<p> 
		Numebr of times: 
		<select id="rep_time" name="rep_time">
			  <option value="">--select--</option>
			  <option value="First time">First time</option>
			  <option value="Second time">Second time</option>
			  <option value="Third time">Third time</option>
			  <option value="Every time">Every time</option>
		</select>
		<input name="number_t" value="Submit" type="submit">
		</form>		
		</p>
		</section>
		<section class="12u 12u$(small)">	
		<table>
		<td width="10%" class="table-wrapper">Date</td>
		<td width="10%" class="table-wrapper">ID</td>
    	<td width="25%" class="table-wrapper">Device</td>
		<td width="25%" class="table-wrapper">Interface</td>
		<td width="25%" class="table-wrapper">File</td>
		<td width="5%" class="table-wrapper">Rep Numbers</td>
		<tr>
		<td>16/09/2015</td>
		<td>1</td>
		<td>Microwave</td>
		<td>Hall Speaker</td>
		<td>Microwave.wav</td>
		<td>Every time</td>
		</tr>
		</table>
		
		</section>

                    
	</div>
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>