
<?php
$name = $_POST['name'];
$lname = $_POST['lname'];
$caretype = $_POST['caretype'];
$speciality = $_POST['speciality'];
$notes = $_POST['notes'];
$id=$_POST['id'];
$server = mysql_connect("localhost","root", "123");
$db =  mysql_select_db("testsensors",$server);
if(isset($_POST['add']))
{$query = mysql_query("INSERT INTO `testsensors`.`pwddetails` (`ID`, `cname`, `clname`, `caretype`, `speciality`, `notes`) VALUES (NULL, '$name', '$lname', '$caretype', '$speciality', '$notes');");}
else if(isset($_POST['del'])) {
$query = mysql_query("DELETE FROM pwddetails WHERE ID = '$id';"); }

?>
<!doctype html>

<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<meta http-equiv="refresh" content="0; url=http://10.44.34.23/caregiverdetails.php" />
</head>

<body>
</body>
</html>
