<html>
<meta charset="UTF-8">
<title>Evaluation Platform</title>
<body>
<form action="scoresubmit.php" method="post">
<h1> Individually Prioritised Problem Assessment (IPPA) </h1>
<h2>Round <select name="round"> <option value="1"> One </option> <option value="2"> Two </option></select></h2>
<p> Formal Caregiver's form. </p>
<p> Please enter your name: <input type="text" name="f_name"></p>
<p> Please enter your last name: <input type="text" name="lname"></p>
<p> Please enter your years of experience: <input type="text" name="exper"></p>


<table border="1" style="width:80%">
  <tr>
    <td width="5%"> <strong> No </strong> </td>
    <td width="70.5%"> <strong> Scenario </strong> </td>
    <td width="12.5%"> <strong> Importance </strong> </td>
    <td width="12%"> <strong> Difficulty </strong> </td>
  <tr>
  <tr>
    <td>1</td>
    <td>The repetitive speech is a prevalent symptom of dementia. The symptom progress has a direct correlation with dementia stage. Therefore, visualising it by the system through its interfaces can indicate the disease progress.</td>
    <td><select name="speech_importance">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="speech_difficulty">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>2</td>
    <td>Dehydration is a dementia symptom that threats PwDs health. The SH should notice it and remind the resident to drink enough water.</td>
    <td><select name="importance_dehydration">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_dehydration">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>3</td>
    <td>
There are telecommunication applications (e.g., Microsoft Skype, Apple FaceTime) providing video calls for computers, tablets and mobile devices via the Internet. However, it is not easy for PwDs to use them. In that regard, The SH should adapt familiar devices (i.e., TV) or natural user interfaces to make the conventional telecommunication applications accessible for PwDs.</td>
    <td><select name="importance_telecommunication">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_telecommunication">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>4</td>
    <td>People misplace personal items inside a home. However, in PwDs' case it occurs more often.  Although the system should inform PwDs and their caregivers about the incidents and the location of misplaced items, it should operate in a way that not causes PwDs constantly depend on it for finding the misplaced items.</td>
    <td><select name="importance_misplace">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_misplace">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>5</td>
    <td>In contrary to the "#4 misplacing personal item" use case table, in this use case PwDs has a more severe dementia. Therefore, it is improbable that they can remember where the lost or misplaced items are. The system should simply help them to find the items.</td>
    <td><select name="importance_Losing">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_Losing">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>6</td>
    <td>It is difficult for elderly people to learn how to use previously unseen devices. For PwDs, the process of learning how to manage the devices is even more complicated. Therefore, the system should provide the necessary guides interactively.</td>
    <td><select name="importance_Learning">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_Learning">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>7</td>
    <td>PwDs cannot remember the time and date. The system simply supports them by stating the time and date through its interfaces. The calendar should get activated by PwDs requests.</td>
    <td><select name="importance_timedate">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_timedate">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>8</td>
    <td>Pacing is a common obstacle for people in early stages of dementia. It happens when PwDs need to use the toilet or drink water during the night time. PwDs face orientation obstacles, therefore when they wake up during the night, they get confused and start walking through the house. The system should support the PwD to go back to sleep.</td>
    <td><select name="importance_pacing">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_pacing">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>9</td>
    <td>Night-time wandering incidents occurs during the late-stage dementia. They can be seen as advanced pacing. As they are extremely dangerous for PwD's health and safety, the system should quickly respond to them.</td>
    <td><select name="importance_NTW">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_NTW">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>10</td>
    <td>Forgetfulness is a common dementia symptom that gets worse as the disease progress. It causes different problems for PwDs, an overwhelming one is forgetting acquaintances' names and faces.  The problem will occur for all the AD patients. The only way to reduce the progress speed and the PwDs' frustration is to constantly remind the acquaintances’ names and faces to them.  </td>
    <td><select name="importance_forget">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_forget">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>11</td>
    <td>Vision difficulties have a noteworthy role in the PwD's accidents (e.g., falling) inside the home.  Lack of proper lighting causes the majority of these accidents. The system should provide adequate lighting.</td>
    <td><select name="importance_vision">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_vision">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>12</td>
    <td>
Late-stage dementia severely affects PwDs' self-awareness consequently they face problems in areas such as personal grooming and hygiene. The system should help the PwD for performing personal grooming and hygiene-related tasks.
</td>
    <td><select name="importance_grooming">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_grooming">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
  <tr>
    <td>13</td>
    <td>Regardless of the SH elderly residents' dementia stage, they benefit from a health monitoring system that also responds to the residents requests for help in emergency situations.
</td>    <td><select name="importance_health">
            <option value=""> - Select - </option>
            <option value="1"> 1- Not important at all </option>
            <option value="2"> 2- Not so important </option>
            <option value="3"> 3- Somewhat important </option>
            <option value="4"> 4- Quite important </option>
            <option value="5"> 5- Most important </option>
            <option value="0"> 6- Not relevant </option>
        </select>
    </td>
    <td>
      <select name="difficulty_health">
              <option value=""> - Select - </option>
              <option value="1"> 1- Not difficult at all </option>
              <option value="2"> 2- Little difficult </option>
              <option value="3"> 3- Quite some diffiulty </option>
              <option value="4"> 4- A lot of difficulty </option>
              <option value="5"> 5- Too much difficulty to perform the activity </option>
              <option value="0"> 6- Not relevant </option>
          </select>

    </td>
  </tr>
</table>
<input name="ev_submit" id="ev_submit" type="submit" value="Send">
</form>

</body>
</html>
