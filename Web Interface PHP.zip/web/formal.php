<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Formal Monitoring Applications</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Configurations</a></li>
						<li><a href="Details.html">About</a></li>
					</ul>
				</nav>
				</nav>
			</header>

		<!-- Main -->
       
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major">
						<h2>Formal Caregivers' Applications</h2>
						<p>You can find a variety of user interfaces for formal caregivers in this page.</p>
					</header>

					<a href="#" class="image fit"><img src="images/pic10.jpg" alt="" /></a>
							
				<div class="row 200%">
						<section class="4u 12u$(small)">
							<a href="NTW.php"><i class="icon big rounded fa-moon-o"></i></a>
							<p>Night-time wandering</p>
						</section>
							
                    
	    <section class="4u 12u$(small)">
							<a href="ghm.php"><i class="icon big rounded  fa-medkit "></i></a>
							<p>General Health Monitoring</p>
						</section>
                        <section class="4u 12u$(small)">
						  <a href="caregiverdetails.php"><i class="icon big rounded fa-television"></i></a>
							<p>List of Caregivers</p>
						</section>
							 <section class="4u 12u$(small)">
						  <a href="pirmonitoring.php"><i class="icon big rounded  fa-location-arrow"></i></a>
							<p>Location Monitoring</p>
						</section>
                         <section class="4u 12u$(small)">
						  <a href="Kitchenmonitoring.php"><i class="icon big rounded  fa-lemon-o"></i></a>
							<p>Kitchen Monitoring</p>
						</section>
						<section class="4u 12u$(small)">
							<a href="ac-formal.php"><i class="icon big rounded  fa-desktop"></i></a>
							<p>Alert Center</p>
						</section>
							<section class="4u 12u$(small)">
							<a href="speech.php"><i class="icon big rounded  fa-microphone"></i></a>
							<p>Repitetive Speech</p>
						</section>
							<section class="4u 12u$(small)">
							<a href="rtls.php"><i class="icon big rounded  fa-tencent-weibo"></i></a>
							<p>Real-time Locating System.</p>
						</section>
						<section class="4u 12u$(small)">
							<a href="com.php"><i class="icon big rounded  fa-comments-o
"></i></a>
							<p> Communications</p>
						</section>
                    	<section class="4u 12u$(small)">
							<a href="ags.php"><i class="icon big rounded  fa-fast-forward"></i></a>
							<p> Automatic Guide playing Syste</p>
						</section>
                    
                    
	</div>
			

	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>