<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("Alertcenter", $con); 
$sth = mysql_query("SELECT c_id, c_reciever_name, c_date, c_type, c_duration, c_r_type FROM `com`");
$maximum_duration = mysql_query("SELECT c_reciever_name, c_duration FROM com WHERE c_duration = (SELECT MAX(c_duration) FROM com)");
$sum_duration_sql = mysql_query("SELECT Sum(C_duration) AS sum_duration FROM com");
//sum 
$sum_duration = mysql_fetch_array($sum_duration_sql);
$sum_minutes=$sum_duration[0];
// the most frequent contact
$max_talk_time = mysql_fetch_array($maximum_duration);
$person_name= $max_talk_time[0];
$person_duration =  $max_talk_time[1];
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Communication</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	
	<body>
		<!-- Header -->
	<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Configurations</a></li>
						<li><a href="Details.html">About</a></li>
					</ul>
				</nav>
				</nav>
	</header>

		<!-- Main -->
        
<section id="main" class="wrapper">
	<div class="container">
		<header class="major">
			<h2>Communication logs and analysis</h2>
			<p>This part shows the information regarding the PwDs social interactions using telecomunication services. </p>
			</header>

						
	<div class="row 100%">
	<section class "12u 12u$(small)">
	<p>In the last month, John talked for <?php echo $sum_minutes;?> minutes using different telecommunication applications. John talked with <?php echo $person_name;?> more than any other contacts for the duration of  <?php echo $person_duration; ?> minutes.</p>

<?php
if ($sum_minutes < 120) 
{
echo '<div class="feature 12u 12u$(small)>
<h3><a href="#"><span style="color: yellow ">Warning</span></a></h3>
<div> <p>The PwD only used used the telecommunication applications for  ' . $sum_minutes . ' times this month which is much lower than expected (120 minutes). Please search the causes for this.</p>
</div>
</div>';
}
?>	
	
	</section>
		<section class="12u 12u$(small)">
			<p>List of instances:</p>
			</section>
				<section class="12u 12u$(small)">
<table>
		<td width="10%" class="table-wrapper">ID</td>
		<td width="31%" class="table-wrapper">Reciever's Name</td>
		<td width="31%" class="table-wrapper">Date</td>
    	<td width="29%" class="table-wrapper">Type</td>
		<td width="21%" class="table-wrapper">Duration</td>
		<td width="21%" class="table-wrapper">Relationship</td>
		<?php
		
		
              while ($row = mysql_fetch_array($sth)) {
                   $time = strtotime($row[1]);
				   $myFormatForView = date("m/d/y g:i A", $time);
				   echo "<tr>";
				   echo "<td>".$row[0]."</td>";
				   echo "<td>".$row[1]."</td>";
				   echo "<td>".$myFormatForView."</td>";
                   echo "<td>".$row[3]."</td>";
				   echo "<td>".$row[4]."</td>";
				   echo "<td>".$row[5]."</td>";
                   echo "</tr>";
				   
               }
		
		?> 
		</table>	
			
							
                    
	</div>
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>