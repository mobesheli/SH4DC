<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con); 

$sth = mysql_query("select * from Sleeping");

/*
---------------------------
example data: Table (Chart)
--------------------------
id, starttime, finishtime, REM, Inbed, wandering_hours
*/
$rows = "['Time', 'REM', 'Inbed'],";

$i = 0;
while($r = mysql_fetch_assoc($sth)) {
	$rows = $rows . "['".$i."', ".$r['REM'].", ".$r['Inbed']."],";
	$i++;
}

$table = "[$rows]";
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Formal Monitoring Applications</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
        <!--Load the Ajax API-->
    <script type="text/javascript"
          src="https://www.google.com/jsapi?autoload={
            'modules':[{
              'name':'visualization',
              'version':'1',
              'packages':['corechart']
            }]
          }"></script>

    <script type="text/javascript">
      google.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable(<?=$table?>);

        var options = {
          title: 'REM vs. Inbedtime',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
	</head>
	<body>


		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Management</a></li>
					</ul>
				</nav>
			</header>
            
		<!-- Main -->
       
			<section id="main" class="wrapper">
				<div class="container">
	
					<header class="major">
						<h2>Night-time wandering</h2>
						<p>Here your can find all the information regarding the PwD's night-time wandering. </p>
					</header>
					<div class="row">
                    
                    <!--this is the div that will hold the pie chart-->
                    <div id="curve_chart" class="feature 6u 12u$(small)" style="height:300px"></div>
                    
                    <div class="feature 6u 12u$(small)">My text here <?php echo $table;?></div>
                    
                    </div>		
                 </div>           
              </section>

	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>