<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con); 

//Table
$sth = mysql_query("SELECT s_id, s_time, s_number_rep FROM `speech`");
$sth22 = mysql_query("SELECT s_id, s_time, s_number_rep FROM `speech`");
//Chart
$sth2 = mysql_query("SELECT * FROM `speech`");
$arows = "['Time', 'Rep'],";
$i = 1;
while($xr = mysql_fetch_assoc($sth2)) {
	$arows = $arows . "['".$i."', ".$xr['s_number_rep']."],";
	$i++;
}
$table = "[$arows]";
//echo $table;
$zad = array();
while(($za = mysql_fetch_array($sth22))) {
    $zad[] = $za;
}
$data = array_column($zad, 's_number_rep');
$rr=max($data);
//print_r ($rr)
?>
<!DOCTYPE html>
<html lang="en">
	<head>
<script type="text/javascript"
          src="https://www.google.com/jsapi?autoload={
            'modules':[{
              'name':'visualization',
              'version':'1',
              'packages':['corechart']
            }]
          }"></script>

    <script type="text/javascript">
      google.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable(<?=$table?>);

        var options = {
          title: 'Highest Repetition incidents per day',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
		<meta charset="utf-8">
		<title>Repetitive Speech</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Management</a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
        
<section id="main" class="wrapper">
	<div class="container">
		<header class="major">
			<h2>Repitetive Speech Analyser</h2>
			<p>Please find out about the repetitive speech analysis of the PwD on this page.</p>
		</header>

						
	<div class="row 100%">
		<section class="12u 12u$(small)">
			<p>Microphones data enable us to calculate the number of the PwD's word repetition in a short span of time. The following table represents the highest record per any given day. </p>
		</section>
				<section class="12u 12u$(small)">
<table>
		<td width="10%" class="table-wrapper">ID</td>
		<td width="31%" class="table-wrapper">Time</td>
    	<td width="59%" class="table-wrapper">Number</td>
		<?php
		
		
              while ($row = mysql_fetch_array($sth)) {
                   $time = strtotime($row[1]);
				   $myFormatForView = date("m/d/y g:i A", $time);
				   echo "<tr>";
				   echo "<td>".$row[0]."</td>";
				   echo "<td>".$myFormatForView."</td>";
                   echo "<td>".$row[2]."</td>";
                   echo "</tr>";
				   
               }
		
		?> 
		</table>	
</section>

<div id="curve_chart" class="feature 12u 12u$(small)" style="height:360px"></div>

<?php

//Speech warning:

if ($rr > 39) 
	{
		echo '<div class="feature 12u 12u$(small)>
		<h3><a href="#"><span style="color: red ">Risky Situation</span></a></h3>
		<div> <p>The PwD repeated a phrase ' . $rr . '  times which is much more than expected threshold.</p>
		</div>
		</div>';
		$Jack = 'The PwD repeated a phrase ' . $rr . '  times which is much more than expected threshold.';
		$Jacky   = mysql_real_escape_string($Jack);
		$a=$rr;
		$b=77;
		$uq = $a.$b;
		$type= rand(1, 2000);
		$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`) VALUES (NULL, 'system', '$type', '0', '0', '0', '$Jacky', '$uq');");
		}
else if ($rr > 25 & $rr <39 )
		{
		echo '<div class="feature 12u 12u$(small)>
		<h3><a href="#"><span style="color: Yellow ">Warning</span></a></h3>
		<div> <p> The PwD repeated a phrase ' . $rr . '  times which is more than expected threshold.</p>
		</div>
		</div>';
		$Jack = 'The PwD repeated a phrase ' . $rr . '  times which is more than expected threshold.';
		$Jacky   = mysql_real_escape_string($Jack);
		$a=$rr;
		$b=771;
		$uq = $a.$b;
		$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`) VALUES (NULL, 'system', '0', '0', '0', '0', '$Jacky', '$uq');");
		}
?> 
                  
	</div>
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>