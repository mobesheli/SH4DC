#This is the fuzzy kernel version 0.0
import time
import MySQLdb
import numpy as np
import skfuzzy as fuzz

      
#moitoring loop
def monitor():

	#loading the database
	#prototype access
	alertdb = MySQLdb.connect(host="localhost",   
		             user="root",         
		             passwd="123", 
		             db="Alertcenter")  

	sensordb = MySQLdb.connect(host="localhost",   
		             user="root",         
		             passwd="123", 
		             db="testsensors")

	alertcur = alertdb.cursor()
	sensorcur = sensordb.cursor()
	sensorcurnumber = sensordb.cursor()
	# Generate universe variables
	x_sleeping = np.arange(0, 8, 1)
	x_ntw = np.arange(0, 20, 1)
	x_hindex  = np.arange(0, 100, 1)
	# Generate fuzzy membership functions
	sleep_hi = fuzz.trimf(x_sleeping, [5, 8, 8])
	sleep_md = fuzz.trimf(x_sleeping, [2, 4, 6])
	sleep_lo = fuzz.trimf(x_sleeping, [0, 0, 3.5])
	ntw_hi = fuzz.trimf(x_ntw, [12, 20, 20])
	ntw_md = fuzz.trimf(x_ntw, [4, 10, 16])
	ntw_lo = fuzz.trimf(x_ntw, [0, 0, 8])
	health_hi = fuzz.trimf(x_hindex, [60, 100, 100])
	health_md = fuzz.trimf(x_hindex, [10, 50, 90])
	health_lo = fuzz.trimf(x_hindex, [0,0, 40])

	#fetching the sleping data
	sensorcur.execute("SELECT SUM(Sleeping_hours) FROM Sleeping")
	sensorcurnumber.execute("SELECT COUNT(Sleeping_hours) FROM Sleeping")
	for row in sensorcur.fetchall():
		summ_sleping= row[0]	
	for count in sensorcurnumber.fetchall():
		number_record = count[0]
	
	sleeping_avg = summ_sleping/number_record
	print 'Sleeping AVG: ', sleeping_avg
	
	

	# Input
	sleep_level_lo = fuzz.interp_membership(x_sleeping, sleep_lo, sleeping_avg)
	sleep_level_md = fuzz.interp_membership(x_sleeping, sleep_md, sleeping_avg)
	sleep_level_hi = fuzz.interp_membership(x_sleeping, sleep_hi, sleeping_avg)

	ntw_level_lo = fuzz.interp_membership(x_ntw, ntw_lo, 16.3)
	ntw_level_md = fuzz.interp_membership(x_ntw, ntw_md, 16.3)
	ntw_level_hi = fuzz.interp_membership(x_ntw, ntw_hi, 16.3)

	# Rule 1 
	active_rule1 = np.fmin(sleep_level_lo, ntw_level_hi)
	health_activation_lo = np.fmin(active_rule1, health_lo) 

	# Rule 2
	active_rule2 = np.fmax(sleep_level_md, ntw_level_md)
	health_activation_md = np.fmin(active_rule2, health_md)

	# Rule 3
	active_rule3 = np.fmax(sleep_level_hi, ntw_level_lo)
	health_activation_hi = np.fmin(active_rule3, health_hi)


	# Aggregate all 3 output membership functions together
	aggregated = np.fmax(health_activation_lo,
		             np.fmax(health_activation_md, health_activation_hi))

	# Calculate defuzzified result
	health = fuzz.defuzz(x_hindex, aggregated, 'centroid')
	print 'PwD\'s health overall health index :', health




	sensordb.commit()
	alertdb.commit()

	sensordb.close()
	alertdb.close()
	time.sleep(5)
while True:
    monitor()
