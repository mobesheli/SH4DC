#This is the fuzzy kernel version 0.0
import time
import MySQLdb
import numpy as np
import skfuzzy as fuzz

      
#moitoring loop
def monitor():

	#loading the database
	#prototype access
	alertdb = MySQLdb.connect(host="localhost",   
		             user="root",         
		             passwd="123", 
		             db="Alertcenter")  

	sensordb = MySQLdb.connect(host="localhost",   
		             user="root",         
		             passwd="123", 
		             db="testsensors")

	alertcur = alertdb.cursor()
	sensorcur = sensordb.cursor()
	sensorcurnumber = sensordb.cursor()
	# Generate universe variables
	x_sleeping = np.arange(0, 8, 1)
	
	x_ntw = np.arange(0, 20, 1)
	
	x_rs = np.arange(0, 90, 1)

	
	x_gc = np.arange(0, 400, 1)


	x_hindex  = np.arange(0, 100, 1)



	# Generate fuzzy membership functions
	sleep_hi = fuzz.trimf(x_sleeping, [5, 8, 8])
	sleep_md = fuzz.trimf(x_sleeping, [2, 4, 6])
	sleep_lo = fuzz.trimf(x_sleeping, [0, 0, 3])
	
	ntw_hi = fuzz.trimf(x_ntw, [12, 20, 20]) 
	ntw_md = fuzz.trimf(x_ntw, [4, 10, 16])
	ntw_lo = fuzz.trimf(x_ntw, [0, 0, 8])
	
	rs_hi = fuzz.trimf(x_rs, [60, 80, 90])
	rs_md = fuzz.trimf(x_rs, [30, 50, 70])
	rs_lo = fuzz.trimf(x_rs, [9, 23, 50])
	rs_no = fuzz.trimf(x_rs, [0, 0, 20])

	gc_hi = fuzz.trimf(x_gc, [150, 220, 320])
	gc_acc = fuzz.trimf(x_gc, [118, 130, 170])
	gc_nor = fuzz.trimf(x_gc, [70, 90, 126])
	gc_lo = fuzz.trimf(x_gc, [0, 0, 85])


	health_healthy = fuzz.trimf(x_hindex, [80, 100, 100])
	health_acceptable = fuzz.trimf(x_hindex, [50,70,90])
	health_poor = fuzz.trimf(x_hindex, [10, 40, 70])
	health_critical = fuzz.trimf(x_hindex, [0,0, 30])
	

	# Fetching the sleping data
	sensorcur.execute("SELECT SUM(Sleeping_hours) FROM Sleeping")
	sensorcurnumber.execute("SELECT COUNT(Sleeping_hours) FROM Sleeping")
	for row in sensorcur.fetchall():
		summ_sleping= row[0]	
	for count in sensorcurnumber.fetchall():
		number_record = count[0]
	
	sleeping_avg = summ_sleping/number_record
	print 'Sleeping Average: ', sleeping_avg
	
	# Fetching night time wandering data and sending alerts
	sensorcur.execute("SELECT SUM(pacing_no) FROM NTW")
	sensorcurnumber.execute("SELECT COUNT(pacing_no) FROM NTW")
	for row in sensorcur.fetchall():
		summ_ntw= row[0]	
	for count in sensorcurnumber.fetchall():
		number_ntw = count[0]
	
	ntw_avg = summ_ntw/number_ntw
	ntw_avg=int(ntw_avg)
	print 'Night time wandering incident / month Average: ', ntw_avg
	
		
	# Fetching repetative speech
	sensorcur.execute("SELECT SUM(s_number_rep) FROM `testsensors`.`speech`")
	sensorcurnumber.execute("SELECT Count(s_number_rep) FROM `testsensors`.`speech`")
	for row_rps in sensorcur.fetchall():
		sum_rps= row_rps[0]	
	for count in sensorcurnumber.fetchall():
		number_rps = count[0]
	avg_rps=sum_rps/number_rps
	avg_rps=int(avg_rps)	
	print 'Average repetative speech incident in the last month: ', avg_rps


	# Fetch Glocuse
	avg_gc = 220
	print 'Average Glocuse last month: ', avg_gc



	# Input
	sleep_level_lo = fuzz.interp_membership(x_sleeping, sleep_lo, sleeping_avg)
	sleep_level_md = fuzz.interp_membership(x_sleeping, sleep_md, sleeping_avg)
	sleep_level_hi = fuzz.interp_membership(x_sleeping, sleep_hi, sleeping_avg)

	ntw_level_lo = fuzz.interp_membership(x_ntw, ntw_lo, ntw_avg)
	ntw_level_md = fuzz.interp_membership(x_ntw, ntw_md, ntw_avg)
	ntw_level_hi = fuzz.interp_membership(x_ntw, ntw_hi, ntw_avg)

	rs_level_no = fuzz.interp_membership(x_rs, rs_no, avg_rps)
	rs_level_lo = fuzz.interp_membership(x_rs, rs_lo, avg_rps)
	rs_level_md = fuzz.interp_membership(x_rs, rs_md, avg_rps)
	rs_level_hi = fuzz.interp_membership(x_rs, rs_hi, avg_rps)

	gc_level_lo = fuzz.interp_membership(x_gc, gc_lo, avg_gc)
	gc_level_nor = fuzz.interp_membership(x_gc, gc_nor, avg_gc)
	gc_level_acc = fuzz.interp_membership(x_gc, gc_acc, avg_gc)
	gc_level_hi = fuzz.interp_membership(x_gc, gc_hi, avg_gc)

	# Rule 1 
	active_rule1 = np.fmin(sleep_level_lo, ntw_level_hi)
	health_activation_poor = np.fmin(active_rule1, health_poor) 

	# Rule 2
	active_rule2 = np.fmax(sleep_level_md,ntw_level_md)
	health_activation_acceptable = np.fmin(active_rule2, health_acceptable)

	# Rule 3
	active_rule3 = np.fmax(sleep_level_hi, ntw_level_lo)
	health_activation_healthy = np.fmin(active_rule3, health_healthy)
	# Rule 4 Too much night time wandering incidents
	if (ntw_level_hi > ntw_level_lo) and (ntw_level_hi > ntw_level_md) :
		ntw_alert = 'The PwD wanderd for ', ntw_avg , ' times in average this month which is hieghr than expected. '
		print ntw_alert
	health_activation_critical = np.fmin(ntw_level_hi, health_critical)

	# Rule 5 Too much repetative speech
	if (rs_level_hi > rs_level_lo) and (rs_level_hi > rs_level_md) and (rs_level_hi > rs_level_no) :
		rs_alert = "The PwD's RPS %s times in average this month which is hieghr than expected." %avg_rps
		print rs_alert 
	health_activation_critical = np.fmin(rs_level_hi, health_critical)
	
	url='speech.php'
	a=avg_rps
	b=5398
	uq=a*b
	alertcur.execute("""INSERT IGNORE INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`, `link`) VALUES (NULL, 'system', '%s', '0', '1', '0', %s, '%s', %s)""",(b,rs_alert,uq,url))
	
	# Rule 6 high glx
	if (gc_level_hi > gc_level_acc) and (gc_level_hi > gc_level_nor) and (gc_level_hi > gc_level_lo) :
		gc_alert = "The PwD's blood Glocuse %s mg/dl in average this month which is hieghr than expected." %avg_gc
		print gc_alert
	health_activation_critical = np.fmin(gc_level_hi, health_critical)

	# Aggregate all 3 output membership functions together
	aggregated = np.fmax(np.fmax(health_activation_critical, health_activation_healthy),
		             np.fmax(health_activation_poor, health_activation_acceptable))
	#print aggregated
	# Calculate defuzzified result
	health = fuzz.defuzz(x_hindex, aggregated, 'centroid')
	print 'PwD\'s health overall health index :', health
	sensorcur.execute("""UPDATE PwDlist SET PwD_overallsituation=%s WHERE PwD_id=11""",(health) )



	sensordb.commit()
	alertdb.commit()

	sensordb.close()
	alertdb.close()
	time.sleep(5)
while True:
    monitor()
