<?php
//testdate
if("" == trim($_POST["month"])){
    $month = '02';
	}
  	else
		$month = $_POST["month"];

if("" == trim($_POST["year"])){
		    $year = '2016';
			}
		  	else
				$year = $_POST["year"];
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("Alertcenter", $con);
// critical system messages.
$csm = mysql_query("SELECT `date2`,`mes`, `msg_id`, `link`, `actiontype` FROM `Messages` WHERE `sender` LIKE 'system' AND `flag` = 0 AND `pr` = 0 AND `date2` LIKE '$year-$month-%' " );
// non-critical system messages.
$nsm = mysql_query("SELECT `date2`,`mes`, `msg_id`, `link` , `actiontype` FROM `Messages` WHERE `sender` LIKE 'system' AND `flag` = 1 AND `pr` = 0 AND `date2` LIKE '$year-$month-%' ");
// critical caregiver messages.
$ccm = mysql_query("SELECT `date2`,`mes`, `msg_id`, `link`, `actiontype` FROM `Messages` WHERE `sender` LIKE 'caregiver' AND `flag` = 0 AND `pr` = 0 AND `date2` LIKE '$year-$month-%' ");
// non-critical caregiver messages.
$ncm = mysql_query("SELECT `date2`,`mes`, `msg_id`, `link`, `actiontype`  FROM `Messages` WHERE `sender` LIKE 'caregiver' AND `flag` = 1 AND `pr` = 0 AND `date2` LIKE '$year-$month-%' ");
// general messages.
$gm = mysql_query("SELECT `date2`,`mes`, `msg_id`, `link`, `actiontype`  FROM `Messages` WHERE `flag` = 2");

//overall_health
$health=mysql_query("SELECT `PwD_overallsituation` FROM `testsensors`.`PwDlist` where `PwD_id`=11");
$heatlh_val=mysql_fetch_array($health);
$overall_sit=$heatlh_val[0];

//toilet monitoring

$sth_t = mysql_query("SELECT `t_id` , `t_time`, `t_type`FROM `testsensors`.`toilet`");
$sth_d = mysql_query("SELECT * FROM `testsensors`.`toilet` WHERE `t_type` = 'defecation'");
$sth_u = mysql_query("SELECT * FROM `testsensors`.`toilet` WHERE `t_type` = 'urination'");
$num_def= mysql_num_rows($sth_d);
$num_ur = mysql_num_rows($sth_u);
$toilet_u = mysql_num_rows($sth_t);
$urinate_per=($num_ur)/($toilet_u)*100;
$to_per=($toilet_u)/30;
if ($to_per < 1)
{
$Jack = 'The PwD used the toilet' . $toilet_u . ' times this month which is much lower than expected.';
$Jacky   = mysql_real_escape_string($Jack);
$a=$toilet_u;
$b=44;
$uq = $a.$b;
$type= rand(1, 2000);
$url= 'ghm.php';
$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`, `link`) VALUES (NULL, 'system', '$type', '0', '0', '0', '$Jacky', '$uq','$url');");
}
if ($urinate_per<70 )
{
$Jack = 'The PwD only urinated  ' .$num_ur. ' times this month which is lower than expected. He might have hyderation issues';
$Jacky   = mysql_real_escape_string($Jack);
$a=$num_ur;
$b=44;
$uq = $a.$b;
$url= 'ghm.php';
$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`, `link`) VALUES (NULL, 'system', '$type', '0', '0', '0', '$Jacky', '$uq','$url');");}
//toilet end
//Cooker usage warning:
$result = mysql_query("SELECT count( DISTINCT(Date) ) FROM `testsensors`.`css_kitchen`");
$row = mysql_fetch_row($result);
$kitchen= (mysql_num_rows($result))/30;
if ($kitchen < 0.2)
{
$Jack = 'The PwD only used the kictchen appliences  ' . $row[0] . ' times this month which is much lower than expected. Please search the causes for this';
$Jacky   = mysql_real_escape_string($Jack);
$a=$row[0];
$b=98;
$uq = $a.$b;
$type= rand(1, 2000);
$url= 'Kitchenmonitoring.php';
$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`, `link`) VALUES (NULL, 'system', '$type', '0', '0', '0', '$Jacky', '$uq','$url');");}
else if ($kitchen > 0.2 && $kitchen < 0.5)
{
}
//tap water
$sth3 = mysql_query("SELECT * FROM `testsensors`.`css_kitchen` WHERE `Sensor_Name` LIKE 'tap' AND `ACT_time_mins` > 10");
$tables = array();
while($r = mysql_fetch_assoc($sth3)) {
	array_push($tables, $r['Date'], $r['ACT_time_mins']);
	/*$tables[] .= "['".$r['Date']."', ".$r['ACT_time_mins']."],";*/
}
$num_rows = mysql_num_rows($sth3);
if ($tables!= NULL) {
	  $John = 'In ' . $num_rows . ' incident(s), the tap water was running for more than 15 mins please check the chart for more details.';
	$Johny   = mysql_real_escape_string($John);
	$r= $num_rows;
	$x= 98;
	$uq2 = $r.$x;
	$type= rand(1, 2000);
	$url='Kitchenmonitoring.php';
	$testtesttest = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`, `link` ) VALUES (NULL, 'system', '$type', '0', '1', '0', '$Johny', '$uq2','$url');");

	/*for ($x = 0; $x <= 4; $x=$x+2) {
    print_r ($tables[0]);
	}*/

}
//Speech warning:
$sth22 = mysql_query("SELECT s_id, s_time, s_number_rep FROM `testsensors`.`speech`");
$zad = array();
while(($za = mysql_fetch_array($sth22))) {
    $zad[] = $za;
}
$data = array_column($zad, 's_number_rep');
$rr=max($data);
if ($rr > 39)
	{
		$Jack = 'The PwD repeated a phrase ' . $rr . '  times which is much more than expected threshold.';
		$Jacky   = mysql_real_escape_string($Jack);
		$a=$rr;
		$b=77;
		$uq = $a.$b;
		$type= rand(1, 2000);
		$url='speech.php';
		$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`, `link`) VALUES (NULL, 'system', '$type', '0', '0', '0', '$Jacky', '$uq', '$url');");
		}
else if ($rr > 25 & $rr <39 )
		{
		$Jack = 'The PwD repeated a phrase ' . $rr . '  times which is more than expected threshold.';
		$Jacky   = mysql_real_escape_string($Jack);
		$a=$rr;
		$b=77;
		$uq = $a.$b;
		$url='speechg.php';
		$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`, `link`) VALUES (NULL, 'system', '0', '0', '0', '0', '$Jacky', '$uq', '$url');");
		}
//telecommunication applications:
$sum_duration_sql = mysql_query("SELECT Sum(C_duration) AS sum_duration FROM `Alertcenter`.`com`");
$sum_duration = mysql_fetch_array($sum_duration_sql);
$sum_minutes=$sum_duration[0];
if ($sum_minutes  < 120 )
	{
		$Jack = 'The PwD only used used the telecommunication applications for ' . $sum_minutes . ' times this month which is much lower than expected (120 minutes). Please search the causes for this. ';
		$Jacky   = mysql_real_escape_string($Jack);
		$a=$sum_minutes;
		$b=198;
		$uq = $a.$b;
		$type= rand(1, 2000);
		$url='com.php';
		$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`, `link`) VALUES (NULL, 'system', '$type', '0', '1', '0', '$Jacky', '$uq', '$url');");
		}


//misplacing items.
$sth_misplaced = mysql_query("SELECT * FROM `testsensors`.`rtls` WHERE `r_type`='misplacing'");
$a2 = mysql_num_rows($sth_misplaced);

if ($a2 > 3 )
	{
		$Jon = '<p>The PwD missplaced the items for ' . $a2 . ' times this month which is higher than expected. ';
		$Jony   = mysql_real_escape_string($Jon);
		$a=$a2;
		$b=5398;
		$uq = $a.$b;
		$type= rand(1, 2000);
		$url='rtls.php';
		$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`, `link`) VALUES (NULL, 'system', '$type', '0', '1', '0', '$Jony', '$uq', '$url');");
		}


?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Formal caregiver's view</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
    <script type="text/javascript">
    $( document ).ready(function() {
      $('#pwd_info_button').click(function(event){
        event.preventDefault();
        $('#PwD_details').toggle();
      });
    });
    </script>
    <script type="text/javascript">
    $( document ).ready(function() {
      $('#add_alert_button').click(function(event){
        event.preventDefault();
        $('#add_alert').toggle();
      });
    });
    </script>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Configurations</a></li>
						<li><a href="Details.html">About</a></li>
					</ul>
				</nav>
				</nav>
			</header>

		<!-- Main -->

<section id="main" class="wrapper">
	<div class="container">
		<header class="major">
			<h2>PwD's Status</h2>
			<p>The PwD's monthly situation report can be seen here.</p>
		</header>
<div align="center" class="box 12u 12u$(small)">
	<div>	<b>Here are the list of available monitoring <a href="formal.php"> applications:</a></b>
	<p>  </p>
	</div>
	<div class="row 200%">

							<a href="caregiverdetails.php" title="List of Caregivers"><i class="icon fa rounded fa-television fa-2x"></i></a>
							<a href="NTW.php" title="Sleep-monitoring"><i class="icon fa rounded fa-moon-o fa-2x"></i></a>
							<a href="ghm.php" title="General Health Monitoring"><i class="icon fa rounded fa-medkit fa-2x"></i></a>
							<a href="speech.php" title="Speech monitoring"><i class="icon fa rounded fa-microphone fa-2x"></i></a>
							<a href="com.php" title="Communications"><i class="icon fa rounded fa-comments-o fa-2x"></i></a>
							<a href="rtls.php" title="Real-time Locating System"><i class="icon fa rounded  fa-eye  fa-2x"></i></a>
							<a href="Kitchenmonitoring.php" title="Kitchen Monitoring"><i class="icon fa rounded fa-lemon-o fa-2x"></i></a>
							<a href="pirmonitoring.php" title="Location Monitoring"><i class="icon fa rounded fa-location-arrow fa-2x"></i></a>
							<a href="ags.php" title="Automatic Guide playing System"><i class="icon fa rounded fa-headphones fa-2x"></i></a>
	</div>
</div>

<div class="row 200%">
		<div class="6u 12u$(small)" >
		<h3><b>The PwD's Overall health index is:</b></h3>


		<?php
		
		if ($overall_sit <= 30)
			{
							echo "
								<i align=center class='icon big rounded fa-exclamation'> </i> <p></p> <h3 align=left><span style='color:#ff0000;'>Critical</span></h3>
								<p>".$overall_sit."</p>
								<p> The PwD's overall situation is critical. </p>
						</div>";
						

			}
			elseif ($overall_sit > 30 && $overall_sit < 55 )
			{
				echo "<i align=center class='icon big rounded fa-eye'> </i> <p></p> <h3 align=left><span style='color:#ff0000;'>Needs Serious Considerations</span></h3>
								<p>".$overall_sit."</p>
								<p> The PwD's overall situation needs considerations. </p>
						</div>";
			}
			elseif ($overall_sit > 55 && $overall_sit < 85 )
			{
				echo "<i align=center class='icon big rounded fa-medkit''> </i> <p></p> <h3 align=left><span style='color:#ff0000;'>Some Risks are detected</span></h3>
								<p>".$overall_sit."</p>
								<p> The PwD's overall situation is not completely stable. </p>
						</div>";
			}				
			else
			{
				echo "
								<i class='icon big rounded fa-check-circle-o'>  </i> <p> </p> <h3 align=left><span style=#F7D358;'><h3>Acceptable Health Condition</h3></span></h5></i>
								<p>".$overall_sit."</p>
								<p> There are no major concerns in PwDs' health.</p>

						</div>";
						

			}
		?>
  <div class="6u 12u$(small)">
  <a id="pwd_info_button" class= "button icon fa-smile-o" href="">PwD details</a>
	<div id="PwD_details" class="12u 12u$(small)" style="display: none">
      <h3><b>Personal Details:</b></h3>
	     <p>
         <span class "image left">
     

		  <img src="/images/JohnDue.jpg" alt="John Due" style="width:200px;height:253px;">
		  <br/>

		  </span>The information below belongs to a PwD named <i>John Due</i>. He is 76 years old retired teacher. He lives independently in a flat in Bournemouth. Jane is his daughter and his only informal caregiver. He is diagnosed with the Mild Cognitive Impairment.
	         <b>Contact Information:</b> Flat 3, Bradburne Road, BH2 5ST. Cell number: 07428521582</p>
		</div>

</div>



			<div class="wrapper 12u 12u$(small)">
				<form action="#" method="POST">
				<strong><p>Please set the report time:</strong>

				<select id="year" name="year"  onchange="" slected="selected" width="100" style="width: 100px">
			  	<option selected="selected" value="2016">2016</option>
					<option value="2015">2015</option>
					<option value="2014">2014</option>
					<option value="2013">2013</option>
				</select>
			<select name="month" id="month" onchange="" size="1"  slected="selected" width="200" style="width: 200px">
					<option value="01">January</option>
					<option selected="selected" value="02"=>February</option>
					<option value="03">March</option>
					<option value="04">April</option>
					<option value="05">May</option>
					<option value="06">June</option>
					<option value="07">July</option>
					<option value="08">August</option>
					<option value="09">September</option>
					<option value="10">October</option>
					<option value="11">November</option>
					<option value="12">December</option>
			</select>
      <br/>
			<input name="Month" value="Sort" type="submit">
</form>
		</div>

		<div class="row 100%">
	<?php echo "<section><p>Currently, the system shows the $month of $year. </p></section>";?>
		<section class="12u 12u$(small)">
			<p>Please consider the following health reports.</p>
		</section>
		<!-- critical system messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #C00">critically risky</span> situations detected by the system. </p>
		</div>
		<div>
		<table>
		<td width="10%" class="table-wrapper">ID</td>
		<td width="18%" class="table-wrapper">Date</td>
    	<td width="56%" class="table-wrapper">Message</td>
      <td width="23%" class="table-wrapper"> Current Action</td>
		<?php


              while ($row = mysql_fetch_array($csm)) {
                   $time = strtotime($row[0]);
									 $url=$row[3];
								   $myFormatForView = date("m/d/y g:i A", $time);
								   echo "<tr>";
                   echo "<td> <a href=".$url.">".$row[2]."</a></td>";
								   echo "<td>".$myFormatForView."</td>";
				           echo "<td>".$row[1]."</td>";
                   echo "<form action='actiontype.php'><td> ";
                          echo $row[4];
										    	echo "<button type=\"submit\" value=\"Submit\">Change</button> <input type='hidden' name='action_id' value='$row[2]'> <input type='hidden' name='action_type' value='$row[4]'> </td>";
                   echo "</form>";
				           echo "</tr>";
				               }
		?>
		</table>
		</div>
		</section>

		<!-- non-critical system messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #CF0">non-critical</span> situation detected by the system. </p>
		</div>
		<div>
		<table>
      <td width="10%" class="table-wrapper">ID</td>
  		<td width="18%" class="table-wrapper">Date</td>
      	<td width="56%" class="table-wrapper">Message</td>
        <td width="23%" class="table-wrapper"> Current Action</td>
		<?php


                  while ($row = mysql_fetch_array($nsm)) {
                       $time = strtotime($row[0]);
    									 $url=$row[3];
    								   $myFormatForView = date("m/d/y g:i A", $time);
    								   echo "<tr>";
                       echo "<td> <a href=".$url.">".$row[2]."</a></td>";
    								   echo "<td>".$myFormatForView."</td>";
    				           echo "<td>".$row[1]."</td>";
                       echo "<form action='actiontype.php'><td> ";
                              echo $row[4];
    										    	echo "<button type=\"submit\" value=\"Submit\">Change</button> <input type=\"hidden\" name=\"id\" value=".$row[2]."> </td></form>";
    				           echo "</tr>";
    				               }
    ?>
		</table>
		</div>
		</section>

		<!-- critical caregiver messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #C00">critically risky</span> situation detected by the caregivers. </p>
		</div>
		<div>
		<table>
      <td width="10%" class="table-wrapper">ID</td>
  		<td width="18%" class="table-wrapper">Date</td>
      	<td width="56%" class="table-wrapper">Message</td>
        <td width="23%" class="table-wrapper"> Current Action</td>
		<?php


                  while ($row = mysql_fetch_array($ccm)) {
                       $time = strtotime($row[0]);
    									 $url=$row[3];
    								   $myFormatForView = date("m/d/y g:i A", $time);
    								   echo "<tr>";
                       echo "<td> <a href=".$url.">".$row[2]."</a></td>";
    								   echo "<td>".$myFormatForView."</td>";
    				           echo "<td>".$row[1]."</td>";
                       echo "<form action='actiontype.php'><td> ";
                              echo $row[4];
    										    	echo "<button type=\"submit\" value=\"Submit\">Change</button> <input type=\"hidden\" name=\"id\" value=".$row[2]."> </td></form>";
    				           echo "</tr>";
    				               }
		?>
		</table>
		</div>
		</section>

	</div>

		<!-- non-critical caregiver messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #CF0">non-critical</span> situations detected by the caregiver. </p>
		</div>
		<div>
		<table>
      <td width="10%" class="table-wrapper">ID</td>
      <td width="18%" class="table-wrapper">Date</td>
        <td width="56%" class="table-wrapper">Message</td>
        <td width="23%" class="table-wrapper"> Current Action</td>
		<?php


                  while ($row = mysql_fetch_array($ncm)) {
                       $time = strtotime($row[0]);
    									 $url=$row[3];
    								   $myFormatForView = date("m/d/y g:i A", $time);
    								   echo "<tr>";
                       echo "<td> <a href=".$url.">".$row[2]."</a></td>";
    								   echo "<td>".$myFormatForView."</td>";
    				           echo "<td>".$row[1]."</td>";
                       echo "<form action='actiontype.php'><td> ";
                              echo $row[4];
    										    	echo "<button type=\"submit\" value=\"Submit\">Change</button> <input type=\"hidden\" name=\"id\" value=".$row[2]."> </td></form>";
    				           echo "</tr>";
    				               }
		?>
		</table>
		</div>
		</section>

		<!-- General messages are shown here-->
		<section class="12u 12u$(small)">
		<div>
		<p>The following table represents the <span style="color: #0F0">General</span> comments. </p>
		</div>
		<div>
		<table>
      <td width="10%" class="table-wrapper">ID</td>
  		<td width="18%" class="table-wrapper">Date</td>
      	<td width="56%" class="table-wrapper">Message</td>
        <td width="23%" class="table-wrapper"> Current Action</td>
		<?php



                  while ($row = mysql_fetch_array($gm)) {
                       $time = strtotime($row[0]);
    									 $url=$row[3];
    								   $myFormatForView = date("m/d/y g:i A", $time);
    								   echo "<tr>";
                       echo "<td> <a href=".$url.">".$row[2]."</a></td>";
    								   echo "<td>".$myFormatForView."</td>";
    				           echo "<td>".$row[1]."</td>";
                       echo "<form action='actiontype.php'><td> ";
                              echo $row[4];
    										    	echo "<button type=\"submit\" value=\"Submit\">Change</button> <input type=\"hidden\" name=\"id\" value=".$row[2]."> </td></form>";
    				           echo "</tr>";
    				               }
		?>
		</table>
		</div>
		</section>
    <section class="12u 12u$(small)" >
    <a id="add_alert_button" class= "button icon fa-shield" href="">Add new alert</a>
    <br/>
		<section id="add_alert" class="12u 12u$(small)" style="display: none">
			<div>
			<p>Please Add new alert here.</p>
			</div>
			<div>



 <form action="asubmit.php" method="post">
			<table width="120" border="0">


		<tr>
				<td height="166">Detail:</td>
				<td><textarea name="mes" id="mes" rows="20" cols="50"></textarea></td>
		</tr>
		<tr>
				<td>Send:</td>
				<td><input type="submit" name="Critical" id="submit" value="Critical">
						<input type="submit" name="Warning" id="submit2" value="Warning">
						<input type="submit" name="General" id="submit3" value="General"></td>
		</tr>
		<tr>
		<td><input type="text" name="ID" value="Enter ID"></td>
		<td><input type="submit" name="delete" id="delete" value="Delete"></td>
		</tr>
</table>
	</form>
			</div>
		</section>
</section>
<section> <p></p> <br/></section>
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>
