<?php
$server = mysql_connect("localhost","root", "123");
$db =  mysql_select_db("testsensors",$server);
//following is the query for table
$query = mysql_query("SELECT `PwD_id`,`PwD_name`,`PwD_overallsituation`,`PwD_carestartdate`, link FROM `PwDlist`
");
//number of cases
$num_pwD=mysql_num_rows($query)

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Monitoring Applications</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Configuration</a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
        
<section id="main" class="wrapper">
	<div class="container">
		<header class="major">
			<h2>The Monitoring Dashboard</h2>
			<p>This page shows the list of the people with dementia that you are involved with and their overall status. </p>
		</header>
				
	<div class="box 4u 8u$(small)">Welcome to the Smart Home for People with Dementia.<br>
			You are logged in as<em> John Smith</em>. <br>
	You have <?php echo $num_pwD; ?> active case.</div>
	<div class="row 100%">
		<section class="12u 12u$(small)">
			<p>Please click on the PwD &quot;stat&quot; for more information.</p>
	<section class="12u 12u$(small)">
		<table>
			<td width="15%" class="table-wrapper">PwD ID</td>
			<td width="15%" class="table-wrapper">Name</td>
			<td width="20%" class="table-wrapper">Stat</td>
			<td width="50%" class="table-wrapper">Start Date</td>
			<?php
			
					 while ($row = mysql_fetch_array($query)) {
					   $time = strtotime($row[3]);
					   $myFormatForView = date("m/d/y g:i A", $time);
					   $url=$row[4];
					   echo "<tr>";
					   echo "<td>".$row[0]."</td>";
					   echo "<td>".$row[1]."</td>";
					   echo "<td> <a href=".$url.">".$row[2]."</a></td>";
					   echo "<td>".$myFormatForView."</td>";
					   echo "</tr>";
					   
				   }
			?> 
		</table>	
	</section>
		</section>
		
		
			
							
                    
	</div>
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>