<?php

session_start();
$_SESSION['date_value']=$_POST['month'];
$testtest=$_SESSION['date_value'];


$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con);

//Table
$sth = mysql_query("SELECT `t_date`,`r_id`,`item_name`,`r_type`,`r_pr` FROM `rtls`");
//Google Chart
$sth_misplaced = mysql_query("SELECT * FROM `rtls` WHERE `r_type`='misplacing'");
$sth_loosing = mysql_query("SELECT * FROM `rtls` WHERE `r_type`='loosing'");
$a = mysql_num_rows($sth_misplaced);
$b = mysql_num_rows($sth_loosing);
$table = "[[\"Incident\", \"Numbers\", { role: 'style' }],
[\"Misplaced\", $a, \"#b87333\"], [\"Lost\", $b, \"silver\"]] ";
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Monitoring Applications</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>

			</script>

			<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<script type="text/javascript"
	           src="https://www.google.com/jsapi?autoload={
	             'modules':[{
	               'name':'visualization',
	               'version':'1',
	               'packages':['corechart']
	             }]
	           }"></script>

	     <script type="text/javascript">
	       google.setOnLoadCallback(drawChart);

	       function drawChart() {
	         var data = google.visualization.arrayToDataTable(<?=$table?>);

	         var options = {
	           title: 'Lost vs. Misplaced',
	           curveType: 'function',
	           legend: { position: 'bottom' }
	         };

	         var chart = new google.visualization.BarChart(document.getElementById('curve_chart'));

	         chart.draw(data, options);
	       }
	     </script>
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Configurations</a></li>
						<li><a href="Details.html">About</a></li>
					</ul>
				</nav>
				</nav>
			</header>

		<!-- Main -->


<section id="main" class="wrapper">
	<div class="container">
		<header class="major">
			<h2>Real-time Locating System</h2>
			<p>Lost or misplaced items</p>
		</header>


	<div class="wrapper">
		<div class="row 200%" >
			<div class="5u 12u$(small)">
				<strong><p>Please slect the month:</p></strong>
			</div>
			<div class="6u 12u$(small)">
			<form action="#" method="POST">
			<select name="month" id="month" onchange="" size="1"  slected="selected">
					<option value="01">January</option>
					<option value="02">February</option>
					<option value="03">March</option>
					<option value="04">April</option>
					<option value="05">May</option>
					<option value="06">June</option>
					<option value="07">July</option>
					<option value="08">August</option>
					<option selected="selected" value="09">September</option>
					<option value="10">October</option>
					<option value="11">November</option>
					<option value="12">December</option>
			</select>
			<input name="Month" value="Month" type="submit">

		</div>
	</div>
	</form>
	<?php
	if ($a > 3) 
	{
	echo '<div class="feature 12u 12u$(small)>
	<h3><a href="#"><span style="color: yellow ">Warning</span></a></h3>
	<div> <p>The PwD missplaced the items for ' . $a . ' times this month which is higher than expected. </p>
	</div>
	</div>';
	}
	?>	
		<section class="12u 12u$(small)">
			<p>The following table illustrates the name of lost or misplaced items with their importance. </p>
		</section>
		<section class="12u 12u$(small)">
			<?php

	echo $testtest; ?>
		</section>
<section class="12u 12u$(small)">
	<table>
		<td width="15%" class="table-wrapper">Date</td>
		<td width="10%" class="table-wrapper">ID</td>
    	<td width="25%" class="table-wrapper">Item</td>
		<td width="25%" class="table-wrapper">Type</td>
		<td width="25%" class="table-wrapper">Priority</td>
		<?php



session_destroy();




		         while ($row = mysql_fetch_array($sth)) {
                   $time = strtotime($row[0]);
				   $myFormatForView = date("m/d/y g:i A", $time);
				   echo "<tr>";
				   echo "<td>".$myFormatForView."</td>";
                   echo "<td>".$row[1]."</td>";
				   echo "<td>".$row[2]."</td>";
				   echo "<td>".$row[3]."</td>";
				   echo "<td>".$row[4]."</td>";
                   echo "</tr>";

               }

		?>
	</table>
</section>
<section>
	<!--The chart that shows the LvsM-->
<div id="curve_chart" class="feature 12u 12u$(small)" style="height:380px"></div>

	<div class="feature 12u 12u$(small)">
		<h1> <strong><em>Loosing vs. Misplacing:</em></strong></h1>
		<p>The chart presents the number of the incidents which the PwD misplaced items vs. the incidents that the PwD lost them.
Misplacing incidents are defined as the situations that, the locating system is able to locate the item inside the house but the item is not in its place.
Loosing incidents happens when the item is not locatable inside the house. </p>
	</div>

	</div>
</section>


	</div>

		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>
