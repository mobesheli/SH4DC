<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con); 
$sth = mysql_query("select * from generalhm");
$rows = "['Time', 'glucose', 'spo2', 'botemp', 'bloodphigh', 'bloodplow', 'airflow'],";
$tables = array('glucose' => "['Time', 'glucose'],",
		        'spo2' => "['Time', 'spo2'],",
				'botemp' => "['Time', 'botemp'],",
				'airflow' => "['Time', 'airflow'],",
				'bloodp' => "['Time', 'bloodphigh', 'bloodplow'],");
$i = 0;
while($r = mysql_fetch_assoc($sth)) {
	$tables['glucose'] .= "['".$i."', ".$r['glucose']."],";
	$tables['spo2'] .= "['".$i."', ".$r['spo2']."],";
	$tables['botemp'] .= "['".$i."', ".$r['botemp']."],";
	$tables['airflow'] .= "['".$i."', ".$r['airflow']."],";
	$tables['bloodp'] .= "['".$i."', ".$r['bloodphigh'].", ".$r['bloodplow']."],";
	
	//$rows = $rows . "['".$i."', ".$r['glucose'].", ".$r['spo2'].", ".$r['botemp'].", ".$r['bloodphigh'].", ".$r['bloodplow'].", ".$r['airflow']."],";
	$i++;
}
$tables['glucose'] = "[".$tables['glucose']."]";
$tables['spo2'] = "[".$tables['spo2']."]";
$tables['botemp'] = "[".$tables['botemp']."]";
$tables['bloodp'] = "[".$tables['bloodp']."]";
$tables['airflow'] = "[".$tables['airflow']."]";
//var_dump($tables);

$sth_t = mysql_query("SELECT `t_id` , `t_time`, `t_type`FROM `toilet`");
$sth_d = mysql_query("SELECT * FROM `toilet` WHERE `t_type` = 'defecation'");
$sth_u = mysql_query("SELECT * FROM `toilet` WHERE `t_type` = 'urination'");
$sth_utype = mysql_query("SELECT * FROM `toilet`");
$num_def= mysql_num_rows($sth_d);
$num_ur = mysql_num_rows($sth_u);
$toilet_u = mysql_num_rows($sth_t);
$urinate_per=($num_ur)/($toilet_u)*100;
$to_per=($toilet_u)/30;

//toilet presentation
/*$urows = "['Time', 'Type'],";
$n = 0;
while($u = mysql_fetch_assoc($sth_utype)) {
	$urows = $urows . "[ '".$n."', ".$u['t_int']."],";;
	$n++;
}
$utable = "[$urows]";
echo $utable;
echo $tables['airflow'];*/
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>General Health Monitoring</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	    <script type="text/javascript"
          src="https://www.google.com/jsapi?autoload={
            'modules':[{
              'name':'visualization',
              'version':'1',
              'packages':['corechart']
            }]
          }"></script>

    <script type="text/javascript">
	var table_glucose = <?=$tables['glucose']?>;
	var table_spo2 = <?=$tables['spo2']?>;
	var table_bloodp = <?=$tables['bloodp']?>;
	var table_botemp = <?=$tables['botemp']?>;
	var table_airflow = <?=$tables['airflow']?>;
		  	
      //google.setOnLoadCallback(drawChart);
      function drawChart(table, plot_title) {
        var data = google.visualization.arrayToDataTable(table);

        var options = {
          title: plot_title,
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
	  
	  // Change the plot according to the selection in hindex
	$( document ).ready(function() {
		drawChart(table_glucose, 'Glucose');//default
		
		$('#hindex').change(function(event){
		    var selection = $(this).val();
		    console.log(selection);
			var selected_table, selected_title;
			switch(selection) {
				case 'glucose':
					selected_table = table_glucose;
					selected_title = 'Glucose in blood';
					break;
				case 'spo2':
					selected_table = table_spo2;
					selected_title = 'SPo2 index';
					break;
				case 'bloodp':
					selected_table = table_bloodp;
					selected_title = 'Blood Pressure';
					break;
				case 'botemp':
					selected_table = table_botemp;
					selected_title = 'Body Temperature';
					break;
				case 'airflow':
					selected_table = table_airflow;
					selected_title = 'Airflow Fluctuations';
					break;
							
			};
			drawChart(selected_table, selected_title);
			
		});
	});
    </script>
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Management</a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
       
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major">
						<h2>General Health Monitoring</h2>
						<p>General Health Monitoring Application</p>
</header>
<div class="feature 6u 12u$(small)" style="text-align:center; margin:0 auto">
<select id="hindex">
   <option value="glucose">Glucose</option>
   <option value="spo2">SPO2</option>
   <option value="bloodp">Blood Pressure</option>
   <option value="botemp">Body Temperature</option>
   <option value="airflow">Airflow Fluctuations</option>
  
 </select> 
</div>
<div class="row">
<div class="feature 12u 12u$(small)">
<h1><em><strong>Health Index:</strong></em><strong><em></em></strong></h1>
<p>Please select the index that you want to monitor.</p>
</div>
<div id="curve_chart" class="feature 12u 12u$(small)" style="height:380px"></div>
<section class="12u 12u$(small)">
The health monitoring application is equipped with Glucose, SPO2, Blood Pressure, Body Temperature and Airflow Fluction readings per sessions. 
</section>
<section>
<h4> Toilet Monitoring</h4>
<p> The following table shows the amount time that PwD used the toilet.</p>
</section>
<section class="12u 12u$(small)">
<table>
		<td width="10%" class="table-wrapper">ID</td>
		<td width="31%" class="table-wrapper">Date</td>
    	<td width="59%" class="table-wrapper">type</td>
		<?php
		
		
              while ($row = mysql_fetch_array($sth_t)) {
                   $time = strtotime($row[1]);
				   $myFormatForView = date("m/d/y g:i A", $time);
				   echo "<tr>";
				   echo "<td>".$row[0]."</td>";
				   echo "<td>".$myFormatForView."</td>";
                   echo "<td>".$row[2]."</td>";
                   echo "</tr>";
               }

		?> 
		</table>	
</section>

<?php 
//Toilet usage warning:

if ($to_per < 1) 
{
echo '<div class="feature 12u 12u$(small)>
<h3><a href="#"><span style="color: red ">Risky Situation</span></a></h3>
<div> <p>The PwD used the toilet ' . $toilet_u . ' times this month which is much lower than expected.</p>
</div>
</div>';
$Jack = 'The PwD used the toilet ' . $toilet_u . ' times this month which is much lower than expected.';
$Jacky   = mysql_real_escape_string($Jack);
$a=$toilet_u;
$b=44;
$uq = $a.$b;
$type= rand(1, 2000);
$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`) VALUES (NULL, 'system', '$type', '0', '0', '0', '$Jacky', '$uq');");
}
else if ($to_per > 1 & $urinate_per<70 )
{
echo '<div class="feature 12u 12u$(small)>
<h3><a href="#"><span style="color: red ">Risky Situation</span></a></h3>
<div> <p>The PwD only used urinated  ' .$num_ur. ' this month which is lower than expected. He might have hyderation issues</p>
</div>
</div>';
$Jack = 'The PwD only used urinated  ' .$num_ur. ' this month which is lower than expected. He might have hyderation issues';
$Jacky   = mysql_real_escape_string($Jack);
$a=$num_ur;
$b=44;
$uq = $a.$b;
$queryalert = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`) VALUES (NULL, 'system', '0', '0', '0', '0', '$Jacky', '$uq');");

}




?> 

</div>
			

	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>