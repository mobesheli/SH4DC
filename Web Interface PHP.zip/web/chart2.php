<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con); 
// The Chart table contains two fields: weekly_task and percentage
// This example will display a pie chart. If you need other charts such as a Bar chart, you will need to modify the code a little to make it work with bar chart and other charts
$sth = mysql_query("select * from Sleeping");

/*
---------------------------
example data: Table (Chart)
--------------------------
id, starttime, finishtime, REM, Inbed, wandering_hours
*/
$rows = "['Time', 'REM', 'Inbed'],";

$i = 0;
while($r = mysql_fetch_assoc($sth)) {
	$rows = $rows . "['".$i."', ".$r['REM'].", ".$r['Inbed']."],";
	$i++;
}

$table = "[$rows]";
?>

<html>
  <head>
  
    <script type="text/javascript"
          src="https://www.google.com/jsapi?autoload={
            'modules':[{
              'name':'visualization',
              'version':'1',
              'packages':['corechart']
            }]
          }"></script>

    <script type="text/javascript">
      google.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable(<?=$table?>);

        var options = {
          title: 'Company Performance',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="curve_chart" style="width: 900px; height: 500px"></div>
  <?php echo $table;?>
  </body>
  
</html>