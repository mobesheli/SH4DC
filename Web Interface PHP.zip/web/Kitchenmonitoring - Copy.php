<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con); 
$sth = mysql_query("SELECT * FROM `css_kitchen`");

$rows = "['Sensor_Name', 'Date', 'ACT_time_mins', 'CLASS'],";

while($r = mysql_fetch_assoc($sth)) {
	$rows = $rows . "['".$r['Sensor_Name']."', ".$r['Date'].", ".$r['ACT_time_mins'].", '".$r['Sensor_Name']."'],";
	
}
$table = "[$rows]";

/*Second Chart Begins Here*/

if("" == trim($_POST['add'])){
    $name = 'Cooker';
} 
  else 
$name = $_POST['add'];
$arows = "['Time','Selected Activity'],";
$sql="SELECT * FROM `css_kitchen` WHERE Sensor_Name LIKE '%" . $name . "%'"; 
$sth2 = mysql_query($sql);
$i=1;
while($xr = mysql_fetch_assoc($sth2)) {
$arows = $arows . "['".$i."', ".$xr['ACT_time_mins']."],";

$i++;	
}
$newtable = "[$arows]";

$sth2 = mysql_query($sql); 
/*experiment warning*/
$sth3 = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'tap' AND `ACT_time_mins` > 10");
$tables = array();
while($r = mysql_fetch_assoc($sth3)) {
	array_push($tables, $r['Date'], $r['ACT_time_mins']);
	/*$tables[] .= "['".$r['Date']."', ".$r['ACT_time_mins']."],";*/
}
$num_rows = mysql_num_rows($sth3);
if ($tables!= NULL) {
	echo "<font color='red'>The tap water was running </font>" ;
	echo $num_rows;
	echo "<font color='red'> time(s) for more than 15 mins please check the chart.</font>";
	/*for ($x = 0; $x <= 4; $x=$x+2) {
    print_r ($tables[0]);
	}*/
 
}
/*experiment kitchen activity*/
$result = mysql_query("SELECT count( DISTINCT(Date) ) FROM css_kitchen");
$toaster = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'toaster'");
$Cooker = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'Cooker'");
$Refrigerator = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'Refrigerator'");
$Microvawe = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'Microvawe'");
$Tap = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'Tap'");

$num_toaster = mysql_num_rows($toaster);
$num_Cooker = mysql_num_rows($Cooker);
$num_Refrigerator = mysql_num_rows($Refrigerator);
$num_Tap = mysql_num_rows($Tap);
$num_Microwave = mysql_num_rows($Tap);

if (!$result) {
    echo 'Could not run query: ' . mysql_error();
    exit;
}
$row = mysql_fetch_row($result);

$tapper=$num_Tap/$row[0]*100;
$Cookerper=$num_Cooker/$row[0]*100;
$Refrigeratorper=$num_Refrigerator/$row[0]*100;
$Microvaweper=$num_Microwave/$row[0]*100;
$toasterper=$num_toaster/$row[0]*100; 

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Kitchen Monitoring</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
        <!--Load the Ajax API-->
    <script type="text/javascript"
          src="https://www.google.com/jsapi?autoload={
            'modules':[{
              'name':'visualization',
              'version':'1',
              'packages':['corechart']
            }]
          }"></script>

   <script type="text/javascript">
    google.load("visualization", "1", {packages:["corechart"]});
    google.setOnLoadCallback(drawSeriesChart);

    function drawSeriesChart() {

      var data = google.visualization.arrayToDataTable(<?=$table?>);

      var options = {
        title: 'Time Spent in a Location Per Date',
        hAxis: {title: 'Date'},
        vAxis: {title: 'Hours'},
        bubble: {textStyle: {fontSize: 11}}
      };

      var chart = new google.visualization.BubbleChart(document.getElementById('series_chart_div'));
      chart.draw(data, options);
    }
	      google.setOnLoadCallback(drawChart2);

      function drawChart2() {
        var data = google.visualization.arrayToDataTable(<?=$newtable?>);

        var options = {
          title: 'Location vs Time',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
	      google.setOnLoadCallback(drawChart2);

      function drawChart2() {
        var data = google.visualization.arrayToDataTable(<?=$newtable?>);

        var options = {
          title: 'Location vs Time',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }

	</script>
    
	</head>
	<body>


		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Management</a></li>
					</ul>
				</nav>
			</header>
            
		<!-- Main -->
       
<section id="main" class="wrapper">
<div class="container">
	
					<header class="major">
						<h2>PwD's Kitchen Monitoring.</h2>
						<p>Kitchen Monitoring System. </p>
					</header>
				
 <div class="row">
  <div id="series_chart_div" class="feature 12u 12u$(small)" style="height:360px"></div>
                     
   <div class="feature 12u 12u$(small)">
     The chart above illustrates the locations in the home and the hours PwD spent on them. 
   </div>
    <div id="curve_chart" class="feature 12u 12u$(small)" style="height:380px"></div>
<div class="feature 12u 12u$(small)">
    <form action="asubmit.php" method="post">
    <input name="add" type="submit" id="add" value="Cooker">
    <input name="add" type="submit" id="add" value="Refrigerator">
    <input name="add" type="submit" id="add" value="Microvawe">
    <input name="add" type="submit" id="add" value="Tap">
    <input name="add" type="submit" id="add" value="Toaster">
    </form>
</div>
   
   
  <div class="feature 12u 12u$(small)">
   <table>
  <caption>
  <em><strong>    Usage Percentages
  </strong></em>
  </caption>
  <tr>
    <td>Device</td>
    <td>Usage Percentage </td>
  </tr>
  <tr>
    <td>Cooker</td>
    <td><?php echo $tapper?></td>
  </tr>
  <tr>
    <td>Refrigerator</td>
    <td><?php echo $Refrigeratorper?></td>
  </tr>
  <tr>
    <td>Microvawe</td>
    <td><?php echo $Microvaweper?></td>
  </tr>
  <tr>
    <td>Water Tap</td>
    <td><?php echo $tapper?></td>
  </tr>
  <tr>
    <td>Toaster</td>
    <td><?php echo $toasterper?></td>
  </tr>
</table>
   </div>
                          
 <div>
 <p>The following shows the device usage percentages over last months</p>
 </span>
 </div>
 
                          
    </section>

	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>