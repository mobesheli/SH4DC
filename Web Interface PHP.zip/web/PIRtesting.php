<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con); 
$result = mysql_query("SELECT count( DISTINCT(Date) ) FROM css_kitchen");
$toaster = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'toaster'");
$Cooker = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'Cooker'");
$Refrigerator = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'Refrigerator'");
$Microvawe = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'Microvawe'");
$Tap = mysql_query("SELECT * FROM `css_kitchen` WHERE `Sensor_Name` LIKE 'Tap'");

$num_toaster = mysql_num_rows($toaster);
$num_Cooker = mysql_num_rows($Cooker);
$num_Refrigerator = mysql_num_rows($Refrigerator);
$num_Tap = mysql_num_rows($Tap);
$num_Microwave = mysql_num_rows($Tap);

if (!$result) {
    echo 'Could not run query: ' . mysql_error();
    exit;
}
$row = mysql_fetch_row($result);

$tapper=$num_Tap/$row[0]*100;
$Cookerper=$num_Cooker/$row[0]*100;
$Refrigeratorper=$num_Refrigerator/$row[0]*100;
$Microvaweper=$num_Microwave/$row[0]*100;
$toasterper=$num_toaster/$row[0]*100; 

?>
<html>
  <body><table>
  <caption>
  <em><strong>    Usage Percentages
  </strong></em>
  </caption>
  <tr>
    <td width="120">Device</td>
    <td width="163">Usage Percentage
    </td>
  </tr>
  <tr>
    <td>Cooker</td>
    <td><?php echo $tapper?></td>
  </tr>
  <tr>
    <td>Refrigerator</td>
    <td><?php echo $Refrigeratorper?></td>
  </tr>
  <tr>
    <td>Microvawe</td>
    <td><?php echo $Microvaweper?></td>
  </tr>
  <tr>
    <td>Water Tap</td>
    <td><?php echo $tapper?></td>
  </tr>
  <tr>
    <td>Toaster</td>
    <td><?php echo $toasterper?></td>
  </tr>
</table>
 
</body>
</html>