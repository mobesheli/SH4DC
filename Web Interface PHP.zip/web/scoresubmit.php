<?php
session_start();

$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("evaluation_results", $con);

if (isset($_POST['f_name']))
{
	$_SESSION['first_name_session']=$_POST['f_name'];
}
$submitted_first_name=$_SESSION['first_name_session'];

//last name
if (isset($_POST['lname']))
{
	$_SESSION['lname']=$_POST['lname'];
}
$submitted_last_name=$_SESSION['lname'];

//experience
if (isset($_POST['exper']))
{
	$_SESSION['exper']=$_POST['exper'];
}
$submitted_exper=$_SESSION['exper'];



//round
if (isset($_POST['round']))
{
	$_SESSION['round']=$_POST['round'];
}
$submitted_round=$_SESSION['round'];


//speech importance
if (isset($_POST['speech_importance']))
{
	$_SESSION['speech_importance']=$_POST['speech_importance'];
}
$submitted_speech_importance=$_SESSION['speech_importance'];


//speech difficulty
if (isset($_POST['speech_difficulty']))
{
	$_SESSION['speech_difficulty']=$_POST['speech_difficulty'];
}
$submitted_speech_difficulty=$_SESSION['speech_difficulty'];

//dehyderation importance

if (isset($_POST['importance_dehydration']))
{
	$_SESSION['importance_dehydration']=$_POST['importance_dehydration'];
}
$submitted_dehydration_importance=$_SESSION['importance_dehydration'];

//dehyderation difficulty

if (isset($_POST['difficulty_dehydration']))
{
	$_SESSION['difficulty_dehydration']=$_POST['difficulty_dehydration'];
}
$submitted_dehydration_difficulty=$_SESSION['difficulty_dehydration'];



//telecomunication importance
if (isset($_POST['importance_telecommunication']))
{
	$_SESSION['importance_telecommunication']=$_POST['importance_telecommunication'];
}
$submitted_telecommunication_importance=$_SESSION['importance_telecommunication'];


//telecomunication difficuly
if (isset($_POST['difficulty_telecommunication']))
{
	$_SESSION['difficulty_telecommunication']=$_POST['difficulty_telecommunication'];
}
$submitted_telecommunication_difficulty=$_SESSION['difficulty_telecommunication'];

//misplace importance
if (isset($_POST['importance_misplace']))
{
	$_SESSION['importance_misplace']=$_POST['importance_misplace'];
}
$submitted_misplace_importance=$_SESSION['importance_misplace'];

//mispalce difficuly
if (isset($_POST['difficulty_misplace']))
{
	$_SESSION['difficulty_misplace']=$_POST['difficulty_misplace'];
}
$submitted_misplace_difficulty=$_SESSION['difficulty_misplace'];

//loosing importance
if (isset($_POST['importance_Losing']))
{
	$_SESSION['importance_Losing']=$_POST['importance_Losing'];
}
$submitted_Losing_importance=$_SESSION['importance_Losing'];

//loosing difficulty
if (isset($_POST['difficulty_Losing']))
{
	$_SESSION['difficulty_Losing']=$_POST['difficulty_Losing'];
}
$submitted_Losing_difficulty=$_SESSION['difficulty_Losing'];

//learning importance
if (isset($_POST['importance_Learning']))
{
	$_SESSION['importance_Learning']=$_POST['importance_Learning'];
}
$submitted_Learning_importance=$_SESSION['importance_Learning'];


//learning difficulty
if (isset($_POST['difficulty_Learning']))
{
	$_SESSION['difficulty_Learning']=$_POST['difficulty_Learning'];
}
$submitted_Learning_difficulty=$_SESSION['difficulty_Learning'];

// timedate importance
if (isset($_POST['importance_timedate']))
{
	$_SESSION['importance_timedate']=$_POST['importance_timedate'];
}
$submitted_timedate_importance=$_SESSION['importance_timedate'];

//timedate difficulty
$submitted_timedate_difficulty=$_POST['difficulty_timedate'];

//pacing importance
$submitted_pacinge_importance=$_POST['importance_pacing'];


//pacing difficulty
$submitted_pacinge_difficulty=$_POST['difficulty_pacing'];

//ntw importance
$submitted_NTW_importance=$_POST['importance_NTW'];

//ntw difficulty
$submitted_NTW_difficulty=$_POST['difficulty_NTW'];

//loosing importance
$submitted_Losing_importance=$_POST['importance_timedate'];


//loosing difficulty
$submitted_Losing_difficulty=$_POST['difficulty_timedate'];

$submitted_Learning_importance=$_POST['importance_Learning'];
$submitted_Learning_difficulty=$_POST['difficulty_Learning'];

$submitted_forget_importance=$_POST['importance_forget'];
$submitted_forget_difficulty=$_POST['difficulty_forget'];

$submitted_vision_importance=$_POST['importance_vision'];
$submitted_vision_difficulty=$_POST['difficulty_vision'];

$submitted_grooming_importance=$_POST['importance_grooming'];
$submitted_grooming_difficulty=$_POST['difficulty_grooming'];

$submitted_health_importance=$_POST['importance_health'];
$submitted_health_difficulty=$_POST['difficulty_health'];

$submit=$_POST['submit'];

switch($_POST['round']){
case '1':
    $round = 'first round';
break;
case '2':
   $round='final round';
break;
}

$score_sum= ($submitted_speech_importance * $submitted_speech_difficulty) + ($submitted_dehydration_importance * $submitted_dehydration_difficulty) + ($submitted_telecommunication_importance * $submitted_telecommunication_difficulty)+($submitted_misplace_importance * $submitted_misplace_difficulty)
+ ($submitted_Losing_importance * $submitted_Losing_difficulty)+ ($submitted_Learning_importance * $submitted_Learning_difficulty)+ ($submitted_timedate_importance * $submitted_timedate_difficulty)+ ($submitted_pacinge_importance * $submitted_pacinge_difficulty)+ ($submitted_NTW_importance * $submitted_NTW_difficulty)
+($submitted_forget_importance * $submitted_forget_difficulty)+ ($submitted_vision_importance * $submitted_vision_difficulty) + ($submitted_grooming_importance * $submitted_grooming_difficulty)+ ($submitted_health_importance * $submitted_health_difficulty);
;
$iipa=($score_sum)/(13);




?>
 <html>
 <meta charset="UTF-8">
 <body>
<p> Dear <?php echo $submitted_first_name;?>, this is your <?php echo $round;?> of evaluation. please check your answer before pressing submit</p>
<p> 1. You gave the repetitive speech scenario the importance score of <?php echo $submitted_speech_importance;?> and the difficulty score of <?php echo $submitted_speech_difficulty;?>. </p>
<p> 2. You gave the dehydration scenario the importance score of <?php echo $submitted_dehydration_importance;?> and the difficulty score of <?php echo $submitted_dehydration_difficulty;?>. </p>
<p> 3. You gave the telecommunication scenario the importance score of <?php echo $submitted_telecommunication_importance;?> and the difficulty score of <?php echo $submitted_telecommunication_difficulty;?>. </p>
<p> 4. You gave the misplacing personal items scenario the importance score of <?php echo $submitted_misplace_importance;?> and the difficulty score of <?php echo $submitted_misplace_difficulty;?>. </p>
<p> 5. You gave the losing personal items scenario the importance score of <?php echo $submitted_Losing_importance;?> and the difficulty score of <?php echo $submitted_Losing_difficulty;?>. </p>
<p> 6. You gave the learning scenario the importance score of <?php echo $submitted_Learning_importance;?> and the difficulty score of <?php echo $submitted_Learning_difficulty;?>. </p>
<p> 7. You gave the forgetting time and date scenario the importance score of <?php echo $submitted_timedate_importance;?> and the difficulty score of <?php echo $submitted_timedate_difficulty;?>. </p>
<p> 8. You gave the pacinge scenario the importance score of <?php echo $submitted_pacinge_importance;?> and the difficulty score of <?php echo $submitted_pacinge_difficulty;?>. </p>
<p> 9. You gave the night time wandering scenario the importance score of <?php echo $submitted_NTW_importance;?> and the difficulty score of <?php echo $submitted_NTW_difficulty;?>. </p>
<p> 10. You gave the forgetting names scenario the importance score of <?php echo $submitted_forget_importance;?> and the difficulty score of <?php echo $submitted_forget_difficulty;?>. </p>
<p> 11. You gave the vision scenario the importance score of <?php echo $submitted_vision_importance;?> and the difficulty score of <?php echo $submitted_vision_difficulty;?>. </p>
<p> 12. You gave the grooming scenario the importance score of <?php echo $submitted_grooming_importance;?> and the difficulty score of <?php echo $submitted_grooming_difficulty;?>. </p>
<p> 13. You gave the repetitive speech scenario the importance score of <?php echo $submitted_health_importance;?> and the difficulty score of <?php echo $submitted_health_difficulty;?>. </p>

<p> Your IPPA result is: <?php echo $iipa?></p>
<form action="#" method="post">
<input name='submit' type='submit' value='Send'>
</form>
<?php echo $submitted_first_name;?>
<?php
if (isset($submit)) {

$ent_command_sql= mysql_query("INSERT INTO `evaluation_results`.`evaluation` (`id`, `time`, `fname`, `lname`, `exp`, `ippa`, `impdif`, `type`, `s1`, `s2`, `s3`, `s4`, `s5`, `s6`, `s7`, `s8`, `s9`, `s10`, `s11`, `s12`, `s13`) VALUES (NULL, CURRENT_TIMESTAMP, '$submitted_first_name', '$submitted_last_name', '$submitted_exper', '33', 'imp', 'FormalCaregiver', '$submitted_speech_importance', '$submitted_dehydration_importance', '$submitted_telecommunication_importance', '$submitted_misplace_importance', '$submitted_Losing_importance', '$submitted_Learning_importance', '$submitted_timedate_importance', '$submitted_pacinge_importance', '$submitted_NTW_importance', '$submitted_forget_importance', '$submitted_vision_importance', '$submitted_grooming_importance', '$submitted_health_importance');");
}


?>

</body>
</html>
