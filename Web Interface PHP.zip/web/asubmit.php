<?php
$sender = 'caregiver';
$date2 = '2015-08-12 14:00:00';
$type= rand(1, 2000);
$pr=0;
$sub_mes=$_POST['mes'];
$id=$_POST['ID'];
$server = mysql_connect("localhost","root", "123");
$db =  mysql_select_db("Alertcenter",$server);


if(isset($_POST['Critical'])) {

	$flag=0;

}
if(isset($_POST['Warning'])) {


	$flag=1;
}
if(isset($_POST['General'])) {

	$flag=2;
}
$var = $flag;
$uq=$type.$var;

if(isset($_POST['Critical']) or isset($_POST['Warning']) or isset($_POST['General']))
	{

	$query = mysql_query("INSERT INTO `Alertcenter`.`Messages` (`msg_id`, `sender`, `type`, `var`, `flag`, `pr`, `mes`, `uq`) VALUES (NULL, '$sender', '$type', '$var', '$flag', '$pr', '$sub_mes', '$uq');");

	}
else if(isset($_POST['delete']))
	{
	$query = mysql_query("DELETE FROM `Alertcenter`.`Messages` WHERE `Messages`.`msg_id` = '$id'");
	}

$var = $flag;
$uq=$type.$var;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Processing your request</title>
<meta http-equiv="refresh" content="0; http://10.44.34.23/ac-formal.php" />
</head>

<body>
</body>
</html>
