<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con); 
$sth = mysql_query("select * from generalhm");
$rows = "['Time', 'glucose', 'spo2', 'botemp', 'bloodphigh', 'bloodplow', 'airflow'],";
$tables = array('glucose' => "['Time', 'glucose'],",
		        'spo2' => "['Time', 'spo2'],",
				'bloodp' => "['Time', 'bloodphigh', 'bloodplow'],");
$i = 0;
while($r = mysql_fetch_assoc($sth)) {
	$tables['glucose'] .= "['".$i."', ".$r['glucose']."],";
	$tables['spo2'] .= "['".$i."', ".$r['spo2']."],";
	$tables['bloodp'] .= "['".$i."', ".$r['bloodphigh'].", ".$r['bloodplow']."],";
	
	//$rows = $rows . "['".$i."', ".$r['glucose'].", ".$r['spo2'].", ".$r['botemp'].", ".$r['bloodphigh'].", ".$r['bloodplow'].", ".$r['airflow']."],";
	$i++;
}
$tables['glucose'] = "[".$tables['glucose']."]";
$tables['spo2'] = "[".$tables['spo2']."]";
$tables['bloodp'] = "[".$tables['bloodp']."]";
//var_dump($tables);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>General Health Monitoring</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	    <script type="text/javascript"
          src="https://www.google.com/jsapi?autoload={
            'modules':[{
              'name':'visualization',
              'version':'1',
              'packages':['corechart']
            }]
          }"></script>

    <script type="text/javascript">
	var table_glucose = <?=$tables['glucose']?>;
	var table_spo2 = <?=$tables['spo2']?>;
	var table_bloodp = <?=$tables['bloodp']?>;
	
      //google.setOnLoadCallback(drawChart);
      function drawChart(table, plot_title) {
        var data = google.visualization.arrayToDataTable(table);

        var options = {
          title: plot_title,
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
	  
	  // Change the plot according to the selection in hindex
	$( document ).ready(function() {
		drawChart(table_glucose, 'Glucose');//default
		
		$('#hindex').change(function(event){
		    var selection = $(this).val();
		    console.log(selection);
			var selected_table, selected_title;
			switch(selection) {
				case 'glucose':
					selected_table = table_glucose;
					selected_title = 'Glucose in blood';
					break;
				case 'spo2':
					selected_table = table_spo2;
					selected_title = 'SPo2';
					break;
				case 'bloodp':
					selected_table = table_bloodp;
					selected_title = 'Blood Pressure';
					break;
			};
			drawChart(selected_table, selected_title);
			
		});
	});
	  
    </script>
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Management</a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
       
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major">
						<h2>General Health Monitoring</h2>
						<p>You can find a variety of user interfaces for formal caregivers in this page.</p>
</header>
<div class="feature 6u 12u$(small)" style="text-align:center; margin:0 auto">
<select id="hindex">
   <option value="glucose">Glucose</option>
   <option value="spo2">SPO2</option>
   <option value="bloodp">Blood Pressure</option>
 </select> 
</div>
<div class="row">
<div class="feature 12u 12u$(small)">
<h1><em><strong>Health Index:</strong></em><strong><em></em></strong></h1>
<p>Please select the index that you want to monitor.</p>
</div>
<div id="curve_chart" class="feature 12u 12u$(small)" style="height:380px"></div>
<section class="12u 12u$(small)">
Airflow sensor (breathing)

</section>
<section class="12u 12u$(small)">
Body temperature sensor

</section>
<section class="12u 12u$(small)">
Blood pressure sensor (sphygmomanometer)

</section>
<section class="12u 12u$(small)">Pulse and oxygen in blood sensor (SPO2)
</section>

</div>
			

	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>