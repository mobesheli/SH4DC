<?php

            $server = mysql_connect("localhost","root", "123");
            $db =  mysql_select_db("testsensors",$server);
            $query = mysql_query("select * from pwddetails");
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>List of PwD's Caregivers</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Management</a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
       
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major">
						<h2>List of Caregivers</h2>
						<p>You can find list of caregivers here.</p>
					</header>
				<div class="row 200%">
			
                    
	    <section class="12u 12u$(small)">
<p>List of caregivers:
The acceptabe values for care type are: <em>formal, informal, social, and none</em>.
<form action="http://10.44.34.23/caregiveradded.php" method="post"> 
<!--<table width="180" border="1">
--> 
	<span class="table-wrapper">
    <section class="12u 6u$(small)">
   	<table>
   	<tr>
    <td class="table-wrapper">ID</td>
    <td class="table-wrapper">Caregiver's Name</td>
    <td class="table-wrapper">Caregiver's Last name</td>
    <td class="table-wrapper">Care type</td>
    <td class="table-wrapper">Speciality</td>
    <td class="table-wrapper">Notes</td>
    
  </tr>
<?php
               while ($row = mysql_fetch_array($query)) {
                   echo "<tr>";
				   echo "<td>".$row[ID]."</td>";
                   echo "<td>".$row[cname]."</td>";
                   echo "<td>".$row[clname]."</td>";
				   echo "<td>".$row[caretype]."</td>";
				   echo "<td>".$row[speciality]."</td>";
				   echo "<td>".$row[notes]."</td>";
                   echo "</tr>";
               }

?> 
<tr>
  	<td class="table-wrapper">AG</td>
    <td class="table-wrapper">
      <input name="name" type="text" id="care_name">
    </td>
    <td class="table-wrapper">
      <input name="lname" type="text" id="care_lname">
    </td>
    <td class="table-wrapper">
      <input name="caretype" type="text" id="care_type">
    </td>
    <td class="table-wrapper">
      <input name="speciality" type="text" id="care_speciality">
    </td>
    <td class="table-wrapper">
      <input name="notes" type="text" id="care_notes">
    </td>
  </tr>
<tr>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td class="table-wrapper">
    <input name="add" type="submit" id="add" value="Add a caregiver">
  </td>
</tr> 
<tr>
  <td class="table-wrapper">
    <input  placeholder="Enter an ID" name="id" type="text" id="care_id">
  </td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td class="table-wrapper">
    <input name="del" type="submit" id="del" value="Delete a caregiver" >
  </td>
</tr> 
</table>

</p>
</section>
	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>