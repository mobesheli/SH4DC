<?php
$con=mysql_connect("localhost","root","123") or die("Failed to connect with database!!!!");
mysql_select_db("testsensors", $con); 
$sth = mysql_query("select * from Sleeping");
$sth2 = mysql_query("select * from Sleeping");
$sth3 = mysql_query("SELECT * FROM `Sleep_Quality`");
/*
---------------------------
example data: Table (Chart)
--------------------------
id, starttime, finishtime, REM, Inbed, wandering_hours
*/
$rows = "['Time', 'REM', 'Inbed'],";
$i = 0;
while($r = mysql_fetch_assoc($sth)) {
	$rows = $rows . "['".$i."', ".$r['REM'].", ".$r['Inbed']."],";
	$i++;
}
$zrows = "['Time', 'Sleeping_hours'],";
$j = 0;
while ($z = mysql_fetch_assoc($sth2)) {
	$zrows = $zrows . "['".$j."', ".$z['Sleeping_hours']."],";
	$j++;
}
$srows = "['Time', 'SleepType'],";
$mcounter = 0;
while ($ss = mysql_fetch_assoc($sth3)) {
	$srows = $srows . "['".$mcounter."', ".$ss['SleepType']."],";
	$mcounter++;
}

$table = "[$rows]";
$table2 = "[$zrows]";
$table3 = "[$srows]";
/*echo $sth3;
echo $table3;*/
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Formal Monitoring Applications</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
        <!--Load the Ajax API-->
    <script type="text/javascript"
          src="https://www.google.com/jsapi?autoload={
            'modules':[{
              'name':'visualization',
              'version':'1',
              'packages':['corechart']
            }]
          }"></script>

    <script type="text/javascript">
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable(<?=$table?>);

        var options = {
          title: 'REM vs. Inbedtime',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
	   google.setOnLoadCallback(drawChart2);
            function drawChart2() {

                var data = google.visualization.arrayToDataTable(<?=$table2?>);

                var options = {
                    title: 'Sleeping hours per day',
                    curveType: 'function',
					legend: { position: 'bottom' }
                };

                var chart = new google.visualization.LineChart(document.getElementById('chart_div2'));

                chart.draw(data, options);

            }
/*New chart starts here*/
	   google.setOnLoadCallback(drawChart3);
            function drawChart3() {

                var data = google.visualization.arrayToDataTable(<?=$table3?>);

                var options = {
                    title: 'Sleep Type',
                    curveType: 'function',
					legend: { position: 'bottom' }
                };

                var chart = new google.visualization.SteppedAreaChart(document.getElementById('chart_div3'));

                chart.draw(data, options);

            }
    </script>
    
	</head>
	<body>


		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Management</a></li>
					</ul>
				</nav>
			</header>
            
		<!-- Main -->
       
			<section id="main" class="wrapper">
				<div class="container">
	
					<header class="major">
						<h2>Night-time wandering and Sleep Analysis</h2>
						<p>Here your can find all the information regarding the PwD's night-time wandering. </p>
					</header>
<div class="feature 6u 12u$(small)" style="text-align:center; margin:0 auto">
<select>
   <option value="John Doe, last night">John Doe, last night</option>
   <option value="John Doe, two nights before">John Doe, two nights before </option>
 </select> 
</div>					
 <div class="row">
  <div id="chart_div3" class="feature 12u 12u$(small)" style="height:360px"></div>
                     
   <div class="feature 12u 12u$(small)">
     <h1> <strong><em>Sleep type per one night</em></strong></h1>
                      <p>The chart above illustrates the PwD's sleep type during a selected night (From 00:00 to 7:00):</p>
                      <ul>
                        <li>The (<em>number 3) </em> represents the times when the patient was not in the bed.</li>
                        <li>The <em>(number 2)</em> represents the times when the patient was awake in the bed.</li>
                        <li>The <em>(number 1)</em> represents the times when the patient was in a light sleep.</li>
                        <li> The<em> (number 0)</em> represents the times when the patient was in a deep sleep. </li>
                      </ul>
   </div>
                                   
             
 
                    <div id="chart_div2" class="feature 12u 12u$(small)" style="height:380px"></div>
                     
   <div class="feature 12u 12u$(small)">
                      <h1> <strong><em>Sleeping Hours per nights</em></strong></h1>
                      <p>The chart exhibits PWD's sleeping hours pers night. </p>
   </div>
                                   
                 
                    
                    <!--this is the div that will hold the pie chart-->
                    <div id="curve_chart" class="feature 12u 12u$(small)" style="height:380px"></div>
                    
                    <div class="feature 12u 12u$(small)">
                      <h1> <strong><em>REM vs. Inbed:</em></strong></h1>
                      <p>The chart exhibits the number of hours that the PwD was sleeping in the <span style="color: #30C">REM</span> (Rapid Eye Movement) stages compare to hours that PwD was <span style="color: #F00">in the bed</span>. </p>
                    </div>
                    
                    </div>		
                          
              </section>

	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>
