<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Formal Monitoring Applications</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Home</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="monitoring.html">Monitoring</a></li>
						<li><a href="http://10.44.34.23:8080/openhab.app?sitemap=demo">Management</a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
       
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major">
						<h2>Social Caregivers' Applications</h2>
						<p>You can find a variety of user interfaces for social caregivers in this page.</p>
					</header>

					<a href="#" class="image fit"><img src="images/pic0n.jpg" alt="" /></a>
							
				<div class="row 200%">
						<section class="4u 12u$(small)">
							<a href="ac.php"><i class="icon big rounded  fa-desktop"></i></a>
							<p>Alert Center</p>
						</section>
							
 
						
                    
	</div>
			

	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row"></div>
					<ul class="copyright">
						<li>&copy; SH4PWD. All rights reserved.</li>
						<li></li>
					</ul>
				</div>
			</footer>

	</body>
</html>